#!/bin/sh

#plates
RATIO=0.25
FACTOR=1
for FILE in plates-2.0 plates-1.5
do
  for mode in directory opencv
  do
    for WIDTH in 40 60 100 200
    do
      ./bin/extractCaptureWindowMultiScale --correct --ratio=$RATIO \
      --width=$WIDTH --factor=$FACTOR \
      --backend=$mode csv/$FILE.csv \
      results/$FILE-$mode-$WIDTH-$RATIO-$FACTOR
    done
    mode=caffe
    width=227
    ./bin/extractCaptureWindowMultiScale --correct --ratio=$RATIO \
    --width=$WIDTH --factor=$FACTOR \
    --backend=$mode csv/$FILE.csv \
    results/$FILE-$mode-$WIDTH-$RATIO-$FACTOR
  done
done

#driving licences
# RATIO=0.85
# for WIDTH in 60 100 200 300
# do
#   for mode in directory opencv caffe
#   do
#     ./bin/extractRect --correct --ratio=$RATIO \
#     --width=$WIDTH --factor=$FACTOR \
#     --backend=$mode csv/drivinglicences.csv \
#     results/drivinglicences-directory-$WIDTH-$RATIO-$FACTOR
#   done
# done
