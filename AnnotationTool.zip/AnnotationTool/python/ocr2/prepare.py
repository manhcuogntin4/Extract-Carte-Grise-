import os
import numpy as np
import math
import sys
import h5py
from matplotlib import pyplot
import glob
import random


sys.path.append("/Users/christopherbourez/technologies/caffe/python")
root_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = "/Users/christopherbourez/technologies/caffe/data/chars74k"

import cv2,cv

import scipy.io as sio


def getDataLst():

	FOLDER_PREFIX = "Sample0"
	# Maps folder name to label
	LABELS = {}
	cnt = 1
	# Labels must be sequentially numbered, starting from zero
	for i in range(10):
	  if cnt < 10:
	    LABELS[FOLDER_PREFIX + "0" + str(cnt)] = cnt-1
	  else:
	    LABELS[FOLDER_PREFIX + str(cnt)] = cnt-1
	  cnt += 1

	for i in range(26):
	  LABELS[FOLDER_PREFIX + str(cnt)] = cnt - 1
	  cnt += 1

	for i in range(26):
	  LABELS[FOLDER_PREFIX + str(cnt)] = cnt - 1
	  cnt += 1

	subdirs = ["Img", "Fnt", "Hnd"]
	lines = []
	for subdir in subdirs:
	  relative = subdir

	  # Fix for Img subdir
	  if subdir.lower() == "img":
	    relative = os.path.join (relative, "GoodImg")
	    relative = os.path.join (relative, "Bmp")
	  elif subdir.lower() == "hnd":
	    relative = os.path.join (relative, "Img")

	  for folder_name, label in LABELS.iteritems():
	    relative_folder = os.path.join(relative, folder_name)
	    folder = os.path.join(data_dir, relative_folder)

	    lst = glob.glob(folder+"/*.png")

	    for i in lst:
	    	#print i
	    	lines.append( (i,label) )
	return lines

def splitDataset(lines):
	random.shuffle(lines)
	training = lines[0: int( len(lines)*0.9) ]
	testing = lines[ int( len(lines)*0.9 ):]
	print len(training), len(testing)

	files = ['training.txt','testing.txt']
	lst_files = [training, testing]
	for file in files:
		with open(root_dir+"/data/"+file,'w') as host_file:
			if 'training' in file:
				data = training
			elif 'testing' in file:
				data = testing
			for line in data:
				host_file.write(line[0]+" "+str(line[1])+"\n")


lines = getDataLst()
splitDataset(lines)
