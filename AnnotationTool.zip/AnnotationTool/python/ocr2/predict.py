import os
import numpy as np
import math
import sys
import h5py
from matplotlib import pyplot

sys.path.append("/home/sizhexi/caffe2/python")

DEPLOY_FILE  = 'examples/caffe-ocr/alpha_deploy.prototxt'
MODEL_FILE   = 'examples/caffe-ocr/model/alpha__iter_26000.caffemodel'
TEST_ROOT    = 'examples/caffe-ocr/training_images/0/'

CAFFE_ROOT = '/home/sizhexi/caffe2/'
script_dir = os.path.dirname(os.path.abspath(__file__))

import caffe
caffe.set_mode_gpu()




#########################################################

def getModelStructure(path):

	MODEL_FILE = path+'/'+'deploy.prototxt'
	DEPLOY_FILE = None


	file_iters = [100000,95000,90000,85000,80000,75000,70000,65000,55000,50000,45000,40000,35000,30000,25000,20000,15000,10000,5000]
	for i in file_iters:
		print i,path+'/model_iter_'+ str(i) +'caffemodel'
		if(  os.path.exists( path+'/'+'model_iter_'+ str(i) +'.caffemodel' )   ):
			DEPLOY_FILE = path+'/'+'model_iter_'+ str(i) +'.caffemodel'
			break

	if( DEPLOY_FILE != None ):
	#caffe.set_mode_gpu()
		net = caffe.Classifier(MODEL_FILE, DEPLOY_FILE,raw_scale=255, image_dims=(64,64))
		print [(k,v.data.shape) for k, v in net.blobs.items()]	

		with open(path+"/structure.txt", 'w') as output:
			for k, v in net.blobs.items():
				output.write( str(k)+"   ".join( str(s) for s in v.data.shape) + '\n'   )
		return net
	else:
		return None

def save(img_path, dir_path):

	im = cv2.imread( img_path )
	arr = img_path.split('/')
	img_name = arr[len(arr)-1]
	print img_name
	cv2.imwrite(dir_path+"/"+img_name,im)


def predict3(net ,  datapath):
	print datapath
	with open(datapath) as hostfile:
		sum = 0
		failed = 0
		false_positive = []
		false_negtive = []
		for line in hostfile:
			#print line
			if( sum < 5000):
				arr = line.split(' ')
				img = caffe.io.load_image(arr[0])
				out = net.predict([img], oversample=False)
				pridect = out.argmax()
				print  out[0].argmax(), arr[1]
				if out[0].argmax() != int(arr[1]):
					failed +=1
			else:
				break

			sum +=1
	print "result",failed, sum, (sum - failed)*1.0/sum

	with open(path+"/structure.txt", 'w') as output:
		for k, v in net.blobs.items():
			output.write( str(k)+"   ".join( str(s) for s in v.data.shape) + '\n'   )
		output.write("result ,  failed:"+str(failed)+"   , sum:"+str(sum)+"    ,  prob:"+ str( (sum - failed)*1.0/sum ) +" \n")		

	
	prob = (sum - failed)*1.0/sum 


folders = ['test1']
for folder in folders:
	path = script_dir+"/experiments/" + folder
	
	net = getModelStructure(path)
	print "afafadfasf"
	if( net != None):
		predict3(net  ,  script_dir+"/data/testing.txt")
