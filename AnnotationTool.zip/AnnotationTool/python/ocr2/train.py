import os
import numpy as np
import math
import sys
import h5py
from matplotlib import pyplot as plt
from PIL import Image

sys.path.append('/usr/local/lib/python2.7/site-packages')
sys.path.append("/Users/christopherbourez/technologies/fast-rcnn/caffe-fast-rcnn/python")

import caffe
import cv2,cv
script_dir = os.path.dirname(os.path.abspath(__file__))

def w(c):
    if c != 0:
        print '\n'
        print ':-('
        print '\n'
        sys.exit()

def runCommand(cmd):
    w(os.system(cmd))

CAFFE_BIN_ROOT = '/Users/christopherbourez/technologies/fast-rcnn/caffe-fast-rcnn/build/tools/caffe'


tests = [ 'test1' ]
cmds = []


for test in tests:
	test_name = test
	#cmd = 'mkdir results/{0}'.format(test_name)
	#os.system(cmd)

	tempalteFile = 'experiments/solver.prototxt.template'
	with open(script_dir+"/"+tempalteFile, 'r') as fd:
		template = fd.read()
		outputFile = 'experiments/{0}/solver.prototxt'.format(test_name)
		#print outputFile
		#print template
		path = script_dir+"/experiments/"+test_name
		print "====================================="
		print path
		print "====================================="
		print script_dir+"/"+outputFile
		with open(script_dir+"/"+outputFile, 'w') as fd:
			fd.write(template.format(path=path))

			#-snapshot=examples/ocr2/experiments/test3/model_iter_90000.solverstate
	cmds.append(CAFFE_BIN_ROOT+' train --solver {0}/solver.prototxt 2>&1 | tee -a {0}/log.txt'.format(path))
	print "finished training"


for cmd in cmds:
	runCommand(cmd)
