import os
import random
import numpy as np
import glob
import sys
import matplotlib.pyplot as plt
import threading
import os.path

sys.path.append("/home/sizhexi/caffe2/python")

import caffe

sys.path.append('/usr/local/lib/python2.7/site-packages')
script_dir = os.path.dirname(os.path.abspath(__file__))


def drawplot(folder,training_loss_lst,testing_loss_lst,accuracy_lst):
	iterations_array = []
	loss_array = []	
	for item in training_loss_lst:
		#print item[0], item[1]
		if(item[1] < 1):
			iterations_array.append(item[0])
			loss_array.append(item[1])	

	print len(iterations_array),len(loss_array)
	plt.subplot(3,1,1)
	plt.plot(iterations_array,loss_array,'ro')

	iterations_array2= []
	loss_array2 = []	
	for item in testing_loss_lst:
		print ',,,',item[0], item[1]
		if(item[1] < 1.0):
			iterations_array2.append(item[0])
			loss_array2.append(item[1])		
	plt.subplot(3,1,2)
	plt.plot(iterations_array2,loss_array2,'ro')


	iterations_array3= []
	accuracy_array = []	
	for item in accuracy_lst:
		#print item[0], item[1]
		iterations_array3.append(item[0])
		accuracy_array.append(item[1])		
	plt.subplot(3,1,3)
	plt.plot(iterations_array3,accuracy_array,'ro')	

	#plt.draw()
	plt.show()
	print folder+"/plot.png"
	#plt.savefig(folder+"plot.png")


def saveresult(folder,training_loss_lst,testing_loss_lst,accuracy_lst):
	print len(training_loss_lst), len(testing_loss_lst), len(accuracy_lst)
	with open(folder+"/output.txt +", 'w') as output:
		output.write("------------- training loss -------------\n")
		for loss in training_loss_lst:
			output.write( str(loss[0])+"  "+  str(loss[1])+"\n")

		output.write("------------- testing loss -------------\n")
		for loss in testing_loss_lst:
			#print loss[0], loss[1]
			output.write( str(loss[0])+"  "+  str(loss[1])+"\n")

		output.write("------------- testing accuracy -------------\n")
		for accuracy in accuracy_lst:
			#print accuracy[0], accuracy[1]
			output.write( str(accuracy[0])+"  "+  str(accuracy[1])+"\n")




def extractLog(folder):

	logfile = folder + "/" + 'log.txt'
	training_loss_lst = []
	testing_loss_lst = []
	accuracy_lst = []
	last_iteration = 0
	with open(logfile, 'r') as read:
		for line in read:
			if "Iteration" in line  and "loss" in line:
				#print line
				training_loss = line.split(',')[1]
				#print line.split(',')[0].split(' ')[6]
				iteration = int( line.split(',')[0].split(' ')[6] )
				last_iteration = iteration
				training_loss_value = float( training_loss.split('=')[1] )
				#print training_loss_value
				training_loss_lst.append(  (iteration,training_loss_value) )
		
			elif "Test net" in line: 
				item = line.split('=')
				label = item[0]
				value = item[1].strip().split("(")[0]
				#print label, value
				
				if "accuracy" in label:
					test_accuracy = value
					accuracy_lst.append(  (last_iteration,test_accuracy) )
				elif "loss" in label:
					test_loss = value
					testing_loss_lst.append(  (last_iteration,test_loss) )


 	drawplot(folder,training_loss_lst,testing_loss_lst,accuracy_lst)
 	saveresult(folder, training_loss_lst,testing_loss_lst,accuracy_lst)


def getModelStructure(path):

	MODEL_FILE = path+'/'+'deploy.prototxt'
	DEPLOY_FILE = None

	file_iters = [10000,95000,90000,85000,80000,75000,70000,65000,55000,50000,45000,40000,35000,30000,25000,20000,15000,10000,5000]
	for i in file_iters:
		if(  os.path.exists( path+'/'+'model_iter_'+ str(i) +'.caffemodel' )   ):
			DEPLOY_FILE = path+'/'+'model_iter_'+ str(i) +'.caffemodel'
			break

	if( DEPLOY_FILE != None ):
	#caffe.set_mode_gpu()
		net = caffe.Classifier(MODEL_FILE, DEPLOY_FILE,raw_scale=255, image_dims=(64,64))
		print [(k,v.data.shape) for k, v in net.blobs.items()]	

		with open(path+"/structure.txt", 'w') as output:
			for k, v in net.blobs.items():
				output.write( str(k)+"   ".join( str(s) for s in v.data.shape) + '\n'   )
				#print k, v.data.shape


    	
def printit():
	threading.Timer(5,printit).start()
	print 'hello world'



#printit()
'''''
'''''
#extractLog(script_dir+"/log")
#'test1','test2','test3',
folders = ['test4'  ]

#folders = ['test21', 'test38-','test39-']
for folder in folders:
	path = script_dir+"/experiments/" + folder

	extractLog(path)
	getModelStructure(path)