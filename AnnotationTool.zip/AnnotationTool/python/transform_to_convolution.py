
import os
os.environ['GLOG_minloglevel'] = '1'
import sys

import ConfigParser
import StringIO
ini_str = '[root]\n' + open("Makefile.config", 'r').read()
ini_str = ini_str.replace(":=", ":")
ini_fp = StringIO.StringIO(ini_str)
config = ConfigParser.ConfigParser()
config.readfp(ini_fp)

sys.path.insert(0, '.')
sys.path.insert(0, 'python/driving_letters_position')
sys.path.insert(0, os.path.expanduser(config.get('root','caffe')) + '/python')

import caffe
import numpy as np
import yaml
import cv2
import cv2.cv as cv
import random

caffe.set_mode_cpu()

def transform(net1, net1_caffemodel, net2, net2_caffemodel):

    print "----------------------"
    print "Net 1 : "
    net = caffe.Net(net1, net1_caffemodel,caffe.TEST)

    print "------"
    print "Blobs :"
    for k, v in net.blobs.items():
        print (k, v.data.shape)

    print "------"
    print "Params :"
    for k, v in net.params.items():
        print (k, v[0].data.shape, v[1].data.shape)

    print "----------------------"
    print "Net 2 : "
    net_full_conv = caffe.Net(net2, net1_caffemodel,caffe.TEST)
    print "------"
    print "Blobs :"
    for k, v in net_full_conv.blobs.items():
        print (k, v.data.shape)

    print "------"
    print "Params :"
    for k, v in net_full_conv.params.items():
        print (k, v[0].data.shape, v[1].data.shape)

    print "OOOO"

    params = []
    params_full_conv = []

    print "----------------------"
    print "Net 1"
    print "Unchanged :"
    for k, v in net.params.items():
        if k in net_full_conv.params.keys():
            print k
        else :
            params.append(k)

    print "----------------------"
    print "Net 2"
    print "Unchanged :"
    for k, v in net_full_conv.params.items():
        if k in net.params.keys():
            print k
        else :
            params_full_conv.append(k)

    print "----------------------"
    print "Transformation"

    for i in range(len(params)):
        print params[i], " -> ", params_full_conv[i]

    print "----------------------"
    fc_params = {pr: (net.params[pr][0].data, net.params[pr][1].data) for pr in params}
    for fc in params:
        print '{} weights are {} dimensional and biases are {} dimensional'.format(fc, fc_params[fc][0].shape, fc_params[fc][1].shape)
    conv_params = {pr: (net_full_conv.params[pr][0].data, net_full_conv.params[pr][1].data) for pr in params_full_conv}

    print "----------------------"
    for conv in params_full_conv:
        print '{} weights are {} dimensional and biases are {} dimensional'.format(conv, conv_params[conv][0].shape, conv_params[conv][1].shape)

    for pr, pr_conv in zip(params, params_full_conv):
        conv_params[pr_conv][0].flat = fc_params[pr][0].flat  # flat unrolls the arrays
        conv_params[pr_conv][1][...] = fc_params[pr][1]
    #
    # print net_full_conv.params["ip1-conv"][1].data[200]

    print "----------------------"
    net_full_conv.save(net2_caffemodel)
    print "File ", net2_caffemodel, " saved"

if __name__ == "__main__":
    transform(sys.argv[1],sys.argv[2], sys.argv[3],sys.argv[4])
