# ./tools/train_net.py --gpu 0 --solver models/VGG16/solver.prototxt \
#     --weights data/imagenet_models/VGG16.v2.caffemodel

# sw = SolverWrapper(solver_prototxt, roidb, output_dir,
#                    pretrained_model=pretrained_model)
#
# print 'Solving...'
# sw.train_model(max_iters)
import sys
# sys.path.insert(0, '~/examples/fast-rcnn/caffe-fast-rcnn/python')
sys.path.insert(0, '/Users/christopherbourez/technologies/caffe/python')

import os
os.environ['GLOG_minloglevel'] = '2'
import caffe
from caffe.proto import caffe_pb2
import numpy as np

# caffe.set_mode_gpu()
solver = caffe.SGDSolver("lenet_solver_position.prototxt")
for k, v in solver.net.blobs.items():
    print (k, v.data.shape)

solver.net.copy_from("lenet_iter_2000.caffemodel")
#solver.net.forward()
#solver.test_nets[0].forward()
#print solver.net.blobs['data'].data[1,0]
#print solver.net.blobs['data'].data.shape

#print solver.test_nets[0].blobs['data'].data[1,0]
#print solver.test_nets[0].blobs['data'].data.shape

niter = 100
test_interval = 25
# losses will also be stored in the log
train_loss = np.zeros(niter)
test_acc = np.zeros(int(np.ceil(niter / test_interval)))
output = np.zeros((niter, 8, 10))

# solver.solve()
# solver.step(1)

# the main solver loop
for it in range(niter):
    print "SGD2"
    solver.step(1)  # SGD by Caffe
#
#     # store the train loss
    train_loss[it] = solver.net.blobs['loss'].data
    print "Train loss", train_loss[it]

    # store the output on the first test batch
    # (start the forward pass at conv1 to avoid loading new data)

    # print "Test forward"
    # solver.test_nets[0].forward(start='conv1')
    # output[it] = solver.test_nets[0].blobs['cls_score'].data
    # print "Test loss", solver.test_nets[0].blobs['accuracy'].data

    # run a full test every so often
    # (Caffe can also do this for us and write to a log, but we show here
    #  how to do it directly in Python, where more complicated things are easier.)

    # if it % test_interval == 0:
    #     print 'Iteration', it, 'testing...'
    #     correct = 0
    #     for test_it in range(1):
    #         print "New test set"
    #         solver.test_nets[0].forward()

        #     correct += sum(solver.test_nets[0].blobs['ip2'].data.argmax(1)
        #                    == solver.test_nets[0].blobs['label'].data)
        # test_acc[it // test_interval] = correct / 1e4

# plt.imshow( )

# solver_param = caffe_pb2.SolverParameter()
# with open(solver_prototxt, 'rt') as f:
#     pb2.text_format.Merge(f.read(), self.solver_param)
#
# solver.net.layers[0].set_roidb(roidb)

    # imdb = get_imdb(args.imdb_name)
    # print 'Loaded dataset `{:s}` for training'.format(imdb.name)
    # roidb = get_training_roidb(imdb)
    #
    # output_dir = get_output_dir(imdb, None)
    # print 'Output will be saved to `{:s}`'.format(output_dir)
    #
    # train_net(args.solver, roidb, output_dir,
    #           pretrained_model=args.pretrained_model,
    #           max_iters=args.max_iters)
