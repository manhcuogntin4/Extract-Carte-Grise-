# ./tools/train_net.py --gpu 0 --solver models/VGG16/solver.prototxt \
#     --weights data/imagenet_models/VGG16.v2.caffemodel

# sw = SolverWrapper(solver_prototxt, roidb, output_dir,
#                    pretrained_model=pretrained_model)
#
# print 'Solving...'
# sw.train_model(max_iters)

import sys
import os
from sets import Set

print("Parsing Makefile.config")
import ConfigParser
import StringIO
ini_str = '[root]\n' + open("Makefile.config", 'r').read()
ini_str = ini_str.replace(":=", ":")
ini_fp = StringIO.StringIO(ini_str)
config = ConfigParser.ConfigParser()
config.readfp(ini_fp)
sys.path.insert(0, '.')
sys.path.insert(0, os.path.expanduser(config.get('root','caffe')) + '/python')

import os
os.environ['GLOG_minloglevel'] = '2'
import caffe
from caffe.proto import caffe_pb2
import numpy as np

sys.path.insert(0, os.path.realpath(sys.argv[1]))

try: 
    config.get('root','CPU_only')
    caffe.set_mode_cpu()
    print "Mode CPU"
except:
    caffe.set_mode_gpu()
    print "Mode GPU"

solver = caffe.SGDSolver(os.path.realpath(sys.argv[1]) + "/solver.prototxt")

loss_names = Set()
acc = False
first_layer = ""
for k, v in solver.net.blobs.items():
    print (k, v.data.shape)
    if k.startswith("conv1") and first_layer == "":
        first_layer = k
    if k=="loss" or k.startswith("loss_"):
        loss_names.add(k)

for k, v in solver.test_nets[0].blobs.items():
    if k.startswith("accuracy"):
        acc = True
        print "Accuracy ok"

print "First layer: ",first_layer

if len(sys.argv) == 4 :
    print "Copying parameters from ",sys.argv[3]
    solver.net.copy_from(sys.argv[3])

#solver.net.forward()
solver.test_nets[0].forward()
#print solver.net.blobs['data'].data[1,0]
# print solver.net.blobs['data'].data.shape

print solver.test_nets[0].blobs['data'].data[1,0]
print solver.test_nets[0].blobs['data'].data.shape



print("Nb iterations : " + sys.argv[2])
niter = int(sys.argv[2])
test_interval = 25
# losses will also be stored in the log
train_loss = np.zeros(niter)
test_acc = np.zeros(int(np.ceil(niter / test_interval)))
output = np.zeros((niter, 8, 10))

# solver.solve()
# solver.step(1)



# the main solver loop
for it in range(niter):
    print "SGD2 ", it
    solver.step(1)  # SGD by Caffe
#
#     # store the train loss
    train_loss[it] = 0
    for loss_name in loss_names:
        train_loss[it] += solver.net.blobs[loss_name].data
    print "Train loss : ", train_loss[it]
    #print "Train loss bbox", solver.net.blobs['loss_bbox'].data

    # store the output on the first test batch
    # (start the forward pass at conv1 to avoid loading new data)

    # print "Test forward"
    solver.test_nets[0].forward(start=first_layer)
    output[it] = 0
    for loss_name in loss_names:
        output[it] += solver.test_nets[0].blobs[loss_name].data
        print "Test ", loss_name, " : ", solver.test_nets[0].blobs[loss_name].data
    #print "Test loss bbox", solver.test_nets[0].blobs['loss_bbox'].data
    if acc:
        print "Test accuracy", solver.test_nets[0].blobs['accuracy'].data

    # run a full test every so often
    # (Caffe can also do this for us and write to a log, but we show here
    #  how to do it directly in Python, where more complicated things are easier.)

    # if it % test_interval == 0:
    #     print 'Iteration', it, 'testing...'
    #     correct = 0
    #     for test_it in range(1):
    #         print "New test set"
    #         solver.test_nets[0].forward()

        #     correct += sum(solver.test_nets[0].blobs['ip2'].data.argmax(1)
        #                    == solver.test_nets[0].blobs['label'].data)
        # test_acc[it // test_interval] = correct / 1e4

# plt.imshow( )

solver.net.save(os.path.realpath(sys.argv[1]) + '/train_val.caffemodel')

print "Model saved in ", os.path.realpath(sys.argv[1]) + '/train_val.caffemodel'

# solver_param = caffe_pb2.SolverParameter()
# with open(solver_prototxt, 'rt') as f:
#     pb2.text_format.Merge(f.read(), self.solver_param)
#
# solver.net.layers[0].set_roidb(roidb)

    # imdb = get_imdb(args.imdb_name)
    # print 'Loaded dataset `{:s}` for training'.format(imdb.name)
    # roidb = get_training_roidb(imdb)
    #
    # output_dir = get_output_dir(imdb, None)
    # print 'Output will be saved to `{:s}`'.format(output_dir)
    #
    # train_net(args.solver, roidb, output_dir,
    #           pretrained_model=args.pretrained_model,
    #           max_iters=args.max_iters)
