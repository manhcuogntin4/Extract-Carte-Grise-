python python/test_stn/train_net_diff.py python/test_stn 1
