# ./tools/train_net.py --gpu 0 --solver models/VGG16/solver.prototxt \
#     --weights data/imagenet_models/VGG16.v2.caffemodel

# sw = SolverWrapper(solver_prototxt, roidb, output_dir,
#                    pretrained_model=pretrained_model)
#
# print 'Solving...'
# sw.train_model(max_iters)

import sys
import os
from sets import Set

print("Parsing Makefile.config")
import ConfigParser
import StringIO
ini_str = '[root]\n' + open("Makefile.config", 'r').read()
ini_str = ini_str.replace(":=", ":")
ini_fp = StringIO.StringIO(ini_str)
config = ConfigParser.ConfigParser()
config.readfp(ini_fp)
sys.path.insert(0, '.')
sys.path.insert(0, os.path.expanduser(config.get('root','caffe')) + '/python')

import os
os.environ['GLOG_minloglevel'] = '2'
import caffe
from caffe.proto import caffe_pb2
import numpy as np

sys.path.insert(0, os.path.realpath(sys.argv[1]))



solver = caffe.SGDSolver(os.path.realpath(sys.argv[1]) + "/solver.prototxt")


solver2 = caffe.SGDSolver(os.path.realpath(sys.argv[1]) + "/solver.prototxt")

loss_names = Set()
acc = False
first_layer = ""
for k, v in solver.net.blobs.items():
    print (k, v.data.shape)
    if k.startswith("conv1") and first_layer == "":
        first_layer = k
    if k=="loss" or k.startswith("loss_"):
        loss_names.add(k)

for k, v in solver.test_nets[0].blobs.items():
    if k.startswith("accuracy"):
        acc = True
        print "Accuracy ok"

print "First layer: ",first_layer

if len(sys.argv) == 4 :
    print "Copying parameters from ",sys.argv[3]
    solver.net.copy_from(sys.argv[3])


print("Nb iterations : " + sys.argv[2])
niter = int(sys.argv[2])
test_interval = 25
# losses will also be stored in the log
train_loss = np.zeros(niter)
test_acc = np.zeros(int(np.ceil(niter / test_interval)))
output = np.zeros((niter, 8, 10))

# solver.solve()
# solver.step(1)
caffe.set_mode_cpu()
solver.step(1)
solver2.step(1)
for k in solver.net.params.keys():
    for j in range(len(solver.net.params[k])):
        print "copie ",k,j
        import copy
        z = copy.deepcopy(solver.net.params[k][j].data)
        solver2.net.params[k][j].data[...] = z
        solver2.net.params[k][j].diff[...] = copy.deepcopy(solver.net.params[k][j].diff)


# the main solver loop
for it in range(niter):

    # for k in solver.net.blobs.keys():
    #     solver.net.blobs[k].data[...] = copy.deepcopy(solver2.net.blobs[k].data)
    #     solver.net.blobs[k].diff[...] = copy.deepcopy(solver2.net.blobs[k].diff)
    caffe.set_mode_cpu()
    print "Mode CPU"
    # solver.net.forward()
    # solver.net.backward()
    solver.step(1)

    caffe.set_mode_gpu()
    print "Mode GPU"
    # solver2.net.forward()
    # solver2.net.backward()
    solver2.step(1)

    for k in solver.net.blobs.keys():
        print k, "data", np.sum(np.abs(solver.net.blobs[k].data - solver2.net.blobs[k].data)), np.allclose(solver.net.blobs[k].data , solver2.net.blobs[k].data, atol=0.01)
        print k, "diff", np.sum(np.abs(solver.net.blobs[k].diff - solver2.net.blobs[k].diff)), np.allclose(solver.net.blobs[k].diff , solver2.net.blobs[k].diff, atol=0.01)
        #print k, solver.net.blobs[k].data - solver2.net.blobs[k].data
    for k in solver.net.params.keys():
        for j in range(len(solver.net.params[k])):
            print "data",k, np.sum(np.abs(solver.net.params[k][j].data - solver2.net.params[k][j].data)), np.allclose(solver.net.params[k][j].data , solver2.net.params[k][j].data, atol=0.01)
            print "diff",k, np.sum(np.abs(solver.net.params[k][j].diff - solver2.net.params[k][j].diff)), np.allclose(solver.net.params[k][j].diff , solver2.net.params[k][j].diff, atol=0.01)
        #[(k, v[0].data.shape, v[1].data.shape) for k, v in net.params.items()]
      # SGD by Caffe
#
#     # store the train loss
    train_loss[it] = 0
    for loss_name in loss_names:
        train_loss[it] += solver.net.blobs[loss_name].data
    print "Train loss : ", train_loss[it]

    train_loss[it] = 0
    for loss_name in loss_names:
        train_loss[it] += solver2.net.blobs[loss_name].data
    print "Train loss 2 : ", train_loss[it]
    #print "Train loss bbox", solver.net.blobs['loss_bbox'].data


    # run a full test every so often
    # (Caffe can also do this for us and write to a log, but we show here
    #  how to do it directly in Python, where more complicated things are easier.)

    # if it % test_interval == 0:
    #     print 'Iteration', it, 'testing...'
    #     correct = 0
    #     for test_it in range(1):
    #         print "New test set"
    #         solver.test_nets[0].forward()

        #     correct += sum(solver.test_nets[0].blobs['ip2'].data.argmax(1)
        #                    == solver.test_nets[0].blobs['label'].data)
        # test_acc[it // test_interval] = correct / 1e4

# plt.imshow( )


# solver_param = caffe_pb2.SolverParameter()
# with open(solver_prototxt, 'rt') as f:
#     pb2.text_format.Merge(f.read(), self.solver_param)
#
# solver.net.layers[0].set_roidb(roidb)

    # imdb = get_imdb(args.imdb_name)
    # print 'Loaded dataset `{:s}` for training'.format(imdb.name)
    # roidb = get_training_roidb(imdb)
    #
    # output_dir = get_output_dir(imdb, None)
    # print 'Output will be saved to `{:s}`'.format(output_dir)
    #
    # train_net(args.solver, roidb, output_dir,
    #           pretrained_model=args.pretrained_model,
    #           max_iters=args.max_iters)
