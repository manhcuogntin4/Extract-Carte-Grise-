import sys
# sys.path.insert(0, '~/examples/fast-rcnn/caffe-fast-rcnn/python')
sys.path.insert(0, '/Users/christopherbourez/technologies/caffe/python')

import os
os.environ['GLOG_minloglevel'] = '2'
import caffe
from caffe.proto import caffe_pb2
import numpy as np

# caffe.set_mode_gpu()
solver = caffe.SGDSolver("lenet_solver_position.prototxt")
for k, v in solver.net.blobs.items():
    print (k, v.data.shape)
