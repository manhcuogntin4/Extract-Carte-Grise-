import os
os.environ['GLOG_minloglevel'] = '1'
import sys
sys.path.insert(0, 'train_caffe_position')
# sys.path.insert(0, '~/examples/fast-rcnn/caffe-fast-rcnn/python')
sys.path.insert(0, '/Users/christopherbourez/technologies/caffe/python')
import caffe
import numpy as np
import yaml
import cv2
import cv2.cv as cv
import random


caffe.set_mode_cpu()

import numpy as np
import matplotlib.pyplot as plt


caffe_root = "/Users/christopherbourez/technologies/caffe/"

net_full_conv = caffe.Net('bvlc_reference_caffenet-conv.prototxt', 'bvlc_reference_caffenet-conv.caffemodel',caffe.TEST)
# load input and configure preprocessing
im = caffe.io.load_image(sys.argv[1])
transformer = caffe.io.Transformer({'data': net_full_conv.blobs['data'].data.shape})
transformer.set_mean('data', np.load(caffe_root + 'python/caffe/imagenet/ilsvrc_2012_mean.npy').mean(1).mean(1))
transformer.set_transpose('data', (2,0,1))
transformer.set_channel_swap('data', (2,1,0))
transformer.set_raw_scale('data', 255.0)
# make classification map by forward and print prediction indices at each location
out = net_full_conv.forward_all(data=np.asarray([transformer.preprocess('data', im)]))
print out['prob'][0].argmax(axis=0)
# show net input and confidence map (probability of the top prediction at each location)
plt.subplot(1, 2, 1)
plt.imshow(transformer.deprocess('data', net_full_conv.blobs['data'].data[0]))
plt.subplot(1, 2, 2)
plt.imshow(out['prob'][0,675])
plt.show()
