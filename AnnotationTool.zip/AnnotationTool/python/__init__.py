import sys
import os
from sets import Set

print("Parsing Makefile.config")
import ConfigParser
import StringIO
ini_str = '[root]\n' + open("Makefile.config", 'r').read()
ini_str = ini_str.replace(":=", ":")
ini_fp = StringIO.StringIO(ini_str)
config = ConfigParser.ConfigParser()
config.readfp(ini_fp)
sys.path.insert(0, '.')
sys.path.insert(0, os.path.expanduser(config.get('root','caffe')) + '/python')

import os
os.environ['GLOG_minloglevel'] = '2'
import caffe
from caffe.proto import caffe_pb2
import numpy as np
from PIL import Image

# sys.path.insert(0, os.path.realpath(sys.argv[1]))

try:
    config.get('root','CPU_only')
    caffe.set_mode_cpu()
    print "Mode CPU"
except:
    caffe.set_mode_gpu()
    print "Mode GPU"
