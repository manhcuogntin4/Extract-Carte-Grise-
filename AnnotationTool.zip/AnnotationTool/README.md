# Fast Quote project

## Compile project

You need to have Python, OpenCV, Caffe and Tesseract (`brew install tesseract`) installed.

In `Makefile.config`, configure the path to your Caffe install and specify to compile on CPU only if your GPU is not NVIDIA.

    make all

Then, to download the models and create the required directories :

    npm install

(config AWS CLI for an access to s3://axard, it is required)

Lastly:

    pip install -r requirements.txt


## Download project data

    echo "export DATA_ROOT=~/axard/fastquote" >> ~/.bash_profile
    mkdir -p $DATA_ROOT
    aws s3 cp s3://axard-encrypted/fastquote $DATA_ROOT --recursive --sse aws:kms --sse-kms-key-id 88648dee-6297-4488-8df0-77c4299d9087


# Annotations

### File format

Rectangle extraction tools create annotations CSV files in the [RotatedRect file format](http://christopher5106.github.io/computer/vision/2015/12/26/file-format-for-computer-vision-annotations.html).


### Annotation tool


    ./bin/annotateRect input_dir output_file.csv

A tool used to annotate rectangles or to show the results (rectangles with `--init` option).

Colors :

- blue rectangle : currently active rectangle to annotate

- green rectangles : remaining rectangles to annotate. Use `--init init_file.csv` option to feed rectangles to annotate to the annotation tool.

- yellow rectangles : annotated rectangles

Keys :

- Click with the mouse to set the center of the active rectangle (blue) or create a new active rectangle at this position.

- Use arrow keys to move the active rectangle (blue)

    - move left (left arrow key)
    - move right (right arrow key)
    - move up (up arrow key)
    - move down (down arrow key)

- Press **FN** while using arrow keys to change orientation/scale of the active rectangle (blue)

    - rotate left (left arrow key)
    - rotate right (right arrow key)
    - augment size (up arrow key)
    - downsize (down arrow key)

- **Any letter**: save the currently active rectangle (blue) with this letter as category / class . For example "0", if there is only one category. The blue rectangle will become yellow.

- **ENTER**: save the letter with the same class as previously.

- **BACKSPACE**: erase the currently active rectangle.

- **ESC**: next init rectangle or next image (without save)

Arguments :

- `--ratio 1.0` is the ratio height/width of the annotation rectangles.

- `--cross` display a cross instead of a rectangle for non-current rectangles, ie previous (yellow) or future (green) rectangles. This is a useful display option when rectangles are too close together.

- `--init init_file.csv` to initialize the rectangles instead of selecting them manually (appear in green). The first one of them will be use as the currently active rectangle (blue). You can still add new rectangles when all init rectangles (green or blue) have been annotated.

-- `--export=output_dir` will not display annotation interface. Saves the annotated images to directory.

Note :

- the annotation tool can be stopped and launched again : it will resume the work from *output_file.csv*, previously annotated rectangles appear in yellow.

- in case the init rectangles are bigger than the image, a white border is added to the image to show the rectangles outside the image.

- although annotation tool can read images in an output_file.csv or init_file.csv outside current exe directory (by adding the CSV dir to the image path), it will save images with the input_dir as base path. So, when annotating, execute the command in the same directory as the output_file.csv.

### Extraction tool

Use annotation information to extract a version of the images :

    ./bin/extractRect [FLAGS] annotations.csv output_dir

Moreove, the tool will create an output CSV file listing the new rectangle coordinates in the format `path,label,center_x,center_y,width,height,rotation,noise_x,noise_y,noise_rotation,noise_scale`.

Extraction extracts at best quality.

Image will be rotated so that annotation window will be parallel to the image borders.

FLAGS :

- `--full_image` will not extract the image along the annotation. Always true in `--backend=opencv` output mode.

- `--skip_rotation` skips rotation information in annotation (all set to 0.0).

- `--factor=1.2` extends the extraction box by a factor of the width and height. Default value is 1.0.

- `--resize_width=400` resizes the output to a width of `resize_width` and a height of `resize_width*ratio`. `--resize_width=0` will not resize the output. Default value is no resize. Not available in `--full_image` and `--backend=opencv` mode.

- `--gray=true` extracts as a gray image. Default is false. Always true in `--backend=opencv` output mode.

- `--noise_translation=0.2` adds a noise in translation of 20% of the width/height. Not taken into consideration for negatives generation.

- `--noise_rotation=30` adds a noise in rotation in `[-noise_rotation°,noise_rotation°]`.

- `--noise_zoomin=2 --noise_zoomout=3` adds a noise in scale factor uniformly distributed in `[1/3,200%]`. Not taken into consideration for negatives generation and in `--full_image` mode.

- `--pepper_noise=0.1 --gaussian_noise=30` adds a pixel noise

- `--samples` is the number of sample to extract per image. Default is 1. Useful in combination with noise option.

- `--merge` : if multiple bounding box per images, will extract the global bounding box containing all rectangles in each image. Default is false.

- `--correct_ratio` : corrects the ratio of the annotated rectangles to the specified `--ratio` by augmenting one of the two dimensions (height or width). Default is false.

- `--add_borders=true` : adds borders to the extracted image to fit the ratio. Default is false. Available only when `--resize_width` not zero.

- `--ratio=1.0` is used in combination to `--correct_ratio` or `--resize-width` options. It defines the ratio (height/width) of the window to extract. The use of `--resize-width` option without `--correct_ratio` will stretch the image to final dimensions.

- `--neg_per_pos=1 --neg_width=0.3` defines the number of negative sample to extract per positives and the width of the capture window in percentage to the width of the image (30%). By default, no negative (0).

- `--backend=directory` defines the output format for storing the results. Possible values are : directory, lmdb, tesseract, opencv. Default value is directory.



# Type detection

Let's create a dataset of ~ 300 images per class for 3 classes (1 -> plates, 2 -> driving licences, 3 -> registration card)

    rm $DATA_ROOT/plaques*.csv
    rm $DATA_ROOT/permis_*.csv
    rm $DATA_ROOT/cg*.csv
    rm -r $DATA_ROOT/resized
    mkdir $DATA_ROOT/resized
    mkdir $DATA_ROOT/resized/merge
    rm -r results/resized
    ln -s $DATA_ROOT/resized/merge results/resized
    for dir in permis_A_1 permis_A1_A permis_AM permis_A permis_europe permis_dos cg cg_dos plaques-alex plaques-immat-chris1 plaques-immat-chris2 plaques-immat-chris3;
      do
        echo Resize of directory: $dir ;
        case ${dir:0:2} in
          pl)
            CLASS=1
            ;;
          pe)
            CLASS=2
            ;;
          cg)
            CLASS=3
            ;;
          *)
            echo "Not found"
            exit 1
        esac
        echo Classe : $CLASS ;
        for i in $DATA_ROOT/$dir/*;
          do
            echo $dir/`basename "$i"`,$CLASS,0,0,0,0,0,0 >> $DATA_ROOT/$dir.csv ;
          done
        ./bin/extractRect $DATA_ROOT/$dir.csv --resize_width=224 --full_image --noise_rotation=180 --samples 5 $DATA_ROOT/resized/$dir ;
        cat $DATA_ROOT/resized/$dir/results.csv >> $DATA_ROOT/resized/merge/results.csv
      done
    mkdir $DATA_ROOT/resized/merge/1
    mkdir $DATA_ROOT/resized/merge/2
    mkdir $DATA_ROOT/resized/merge/3
    cp $DATA_ROOT/resized/permis_*/2/* $DATA_ROOT/resized/merge/2/
    cp $DATA_ROOT/resized/cg*/3/* $DATA_ROOT/resized/merge/3/
    cp $DATA_ROOT/resized/plaques*/1/* $DATA_ROOT/resized/merge/1/




Download Googlenet model

    cd ~/technologies/caffe
    ./scripts/download_model_binary.py models/bvlc_reference_caffenet
    ./scripts/download_model_binary.py models/bvlc_googlenet
    ./scripts/download_model_binary.py models/bvlc_alexnet


Train :

- with Caffenet :

        python python/train_net.py python/document_category_caffenet 500 ~/technologies/caffe/models/bvlc_reference_caffenet/bvlc_reference_caffenet.caffemodel

        cp python/document_category_caffenet/deploy.prototxt models/types/train_val.prototxt
        cp python/document_category_caffenet/train_val.caffemodel models/types/train_val.caffemodel

gives ~0.07


- or with Googlenet

        python python/train_net.py python/document_category_googlenet 500 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel

        cp python/document_category_googlenet/deploy.prototxt models/types/train_val.prototxt
        cp python/document_category_googlenet/train_val.caffemodel models/types/train_val.caffemodel



# Plates

### Letter reading

Extract automatically contours/bounding boxes of letters from the license plate.

    ./bin/plateLetterBoundingBoxes $DATA_ROOT/plaques-alex rr_plate_letter_boundingboxes.csv

Then, annotate by typing the letter value for the current bounding box (blue)

    ./bin/annotateRect $DATA_ROOT/plaques-alex output_letters.csv --init rr_plate_letter_boundingboxes.csv  --ratio 1.6

Examples of results in $DATA_ROOT : rr_plates_train_letters.csv rr_plates_test_letters.csv rr_plates_train_small_letters.csv (Reduced sized training file for Opencv)

Extract to a directory of files to check :

    ./bin/extractRect $DATA_ROOT/rr_plates_train_letters.csv --skip_rotation --resize_width=28 --ratio=1.0 --add_borders=true --gray output

![](tutorial/img/plate_letter_zero.jpg) ![](tutorial/img/plate_letter_one.jpg) ![](tutorial/img/plate_letter_two.jpg) ![](tutorial/img/plate_letter_three.jpg)    


Extract to LMDB for Caffe training and train the network

    ./bin/extractRect $DATA_ROOT/rr_plates_train_letters.csv --skip_rotation --resize_width=28 --ratio=1.0 \
    --add_borders=true --gray --backend=lmdb results/train_lmdb

    ./bin/extractRect $DATA_ROOT/rr_plates_test_letters.csv --skip_rotation --resize_width=28 --ratio=1.0 \
    --add_borders=true --gray --backend=lmdb results/test_lmdb

    ~/technologies/caffe/build/tools/caffe train --solver=models/plates_letters/lenet_solver.prototxt

    cp models/plates_letters/lenet_iter_2000.caffemodel models/plates_letters/deploy.caffemodel

To have a look if the database is ok and test the network in iPython, run `ipython notebook` command and have a look at [iPython notebook example](http://localhost:8888/notebooks/Have%20a%20look.ipynb).

Extract for tesseract training to create a directory with two files, a TIFF file `lpfra.std.exp0.tif` and a Box File `lpfra.std.exp0.box` :

    ./bin/extractRect $DATA_ROOT/rr_plates_train_small_letters.csv --skip_rotation --resize_width=28 --ratio=1.0 --add_borders=true --gray --backend=tesseract results/tesseract-training-data

Following [these instructions](http://christopher5106.github.io/optical/character/recognition/2015/09/01/training-optical-character-recognition-technology-tesseract.html) with `newlang="newfra"`, train Tesseract with these two files.


Score Letter recognition

    ./bin/scoreLetters tesseract $DATA_ROOT/rr_plates_test_letters.csv
    ./bin/scoreLetters caffe $DATA_ROOT/rr_plates_test_letters.csv models/plates_letters/deploy.prototxt models/plates_letters/deploy.caffemodel


### Plate detection

Annotate missing letters (add the bounding boxes that have not been extracted automatically)

    cp $DATA_ROOT/rr_plates_train_letters.csv rr_plates_all_letters.csv
    ./bin/annotateRect $DATA_ROOT/plaques-alex rr_plates_all_letters.csv --ratio 1.2

Example of results in DATA_ROOT : rr_plates_all_letters.csv


Extract precisely :

    ./bin/extractRect $DATA_ROOT/rr_plates_all_letters.csv --resize_width=60 --ratio=0.25  \
    --merge --correct_ratio --gray  results/plates-directory-1-60-0.25

![plate factor 1](tutorial/img/plate_extract_factor_1.jpg)

Extract with a border of 1.5 :

    ./bin/extractRect $DATA_ROOT/rr_plates_all_letters.csv --resize_width=60 --ratio=0.25  \
    --merge --correct_ratio --gray --factor=1.5 results/plates-directory-1.5-60-0.25

![plate extract factor 1.5](tutorial/img/plate_extract_factor_1.5.jpg)

and preserving rotation :

    ./bin/extractRect $DATA_ROOT/rr_plates_all_letters.csv --skip_rotation --resize_width=60 \
    --ratio=0.25  --merge --correct_ratio --gray --factor=1.5 \
    results/plates-directory-1.5-60-0.25-R

![plate](tutorial/img/plate_extract_factor_1.5_rotation.jpg)


Extract to OpenCV training format and following [this best practice](http://christopher5106.github.io/computer/vision/2015/10/19/create-an-object-detector.html), train the classifier :

    WIDTH=60
    RATIO=0.25
    NUMPOS=1023
    FACTOR=10

    ./bin/extractRect $DATA_ROOT/rr_plates_all_letters.csv --ratio=0.25 --merge \ --correct_ratio --gray --skip_rotation --factor=1.5 --backend=opencv \ results/plates-opencv-$WIDTH-$RATIO

    cd results/plates-opencv-$WIDTH-$RATIO

    opencv_createsamples -info pos/info.dat -vec pos.vec -w $WIDTH -h $(expr $WIDTH*$RATIO/1 |bc) -num $NUMPOS

    mkdir data
    opencv_traincascade -data data -vec pos.vec  -bg $DATA_ROOT/negatives/negatives.txt -w $WIDTH \
      -h $(expr $WIDTH*$RATIO/1 |bc) -numPos $(expr $NUMPOS*0.85/1 |bc) -numNeg $(expr $FACTOR*$NUMPOS*0.85/1 |bc)  \
      -precalcValBufSize 1024 -precalcIdxBufSize 1024


### Recognize and score

Recognize license Plate with Tesseract

    ./bin/recognizePlateWithTesseract input_dir eng output_dir

or with Caffe

    ./bin/recognizePlateWithCaffe results/plates-opencv-$WIDTH-$RATIO-$FACTOR/data/cascade.xml input_dir output_dir

It will create a `results.csv` file with one line per image :

    image_path,recognized_license_plate

and create images with the indications how the detection occurred.


Score Plate recognition

    ./bin/scorePlates [tesseract|caffe] $DATA_ROOT/rr_plates.csv


# Driving licenses


### Document zone annotation

Annotate a driving license zone

    ./bin/annotateRect $DATA_ROOT/permis_A_A1 rr_permis_A_A1.csv --ratio 0.85

Example of result in DATA_ROOT : rr_permis_A_A1.csv


### Full document localization

Let's localize the full driving licence :

    #convert zones to full driving license documents
    ./bin/extractRect --full_image $DATA_ROOT/rr_permis_A_A1.csv --noise_translation=0.2 --noise_rotation=180 --samples 40 --factor_width=3.1 --factor_height=1.8 --offset_x=-0.05  --offset_y=0.15 --resize_width=227 results/drivinglicenses

    ./bin/annotateRect results/drivinglicenses/0 results/drivinglicenses/results.csv

    python python/train_net.py python/driving_full_translation_rotation_scale_alexnet 500 ~/technologies/caffe/models/bvlc_alexnet/bvlc_alexnet.caffemodel

    ./bin/localize python/driving_full_translation_rotation_scale_alexnet results/drivinglicenses/0 output_f

    ./bin/annotateRect output_f/_ output_f/results.csv -export=output_f

which gives 0.05

![](tutorial/img/convertZoneToDriving.png) ![](tutorial/img/convertZoneToDriving2.png)

    python python/train_net.py python/driving_full_translation_rotation_scale_googlenet 1000 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel

gives

50 : 0.17
150 : 0.07
200 : 0.08
300 : 0.06
500 : 0.03
600 : 0.02
700 : 0.02
800 : 0.02
900 : 0.02
1000 : 0.017


    ./bin/localize python/driving_full_translation_rotation_scale_googlenet/ results/drivinglicenses/0 output_full_googlenet

    ./bin/annotateRect output_full_googlenet/_ output_full_googlenet/results.csv -export=output5


Let's try on original data :

    ./bin/localize python/driving_full_translation_rotation_scale_googlenet/ $DATA_ROOT/permis_A_A1 output_full_googlenet8

    ./bin/annotateRect output_full_googlenet8/_/ output_full_googlenet8/results.csv

    cp python/driving_full_translation_rotation_scale_googlenet/deploy.prototxt models/driving/orientation.prototxt
    cp python/driving_full_translation_rotation_scale_googlenet/train_val.caffemodel models/driving/orientation.caffemodel


### Document zones extraction

Redress images :

    ./bin/extractRect --full_image $DATA_ROOT/rr_permis_A_A1.csv results/permis_A_A1_redressed

Check if during the redress operation, annotations have been maintained :

    cd results/permis_A_A1_redressed
    ../../bin/annotateRect 0 results.csv --ratio 0.85

![](tutorial/img/driving_check_redress.png)

Extract to directory to have a look

    ./bin/extractRect --resize_width=100 --ratio=0.85 \
    $DATA_ROOT/rr_permis_A_A1.csv results/permis_A_A1-directory-100-0.85

![](tutorial/img/driving_annotation_example.jpg)

Extract and train Driving licenses with openCV

    WIDTH=50
    RATIO=0.85
    NUMPOS=117
    FACTOR=10

    ./bin/extractRect --resize_width=$WIDTH --ratio=$RATIO --backend=opencv\
    $DATA_ROOT/rr_permis_A_A1.csv results/permis_A_A1_redressed-opencv-$WIDTH-$RATIO

    cd results/permis_A_A1_redressed-opencv-$WIDTH-$RATIO

    opencv_createsamples -info pos/info.dat -vec pos.vec -w $WIDTH -h $(expr $WIDTH*$RATIO/1 |bc) -num $NUMPOS

    mkdir data

    opencv_traincascade -data data -vec pos.vec -bg $DATA_ROOT/negatives/negatives.txt -w $WIDTH \
      -h $(expr $WIDTH*$RATIO/1 |bc) -numPos $(expr $NUMPOS*0.85/1 |bc) -numNeg $(expr $FACTOR*$NUMPOS*0.85/1 |bc)  \
      -precalcValBufSize 1024 -precalcIdxBufSize 1024 -featureType HAAR

    cp cascade.xml ../../models/driving.xml


### Letter Localization

Let's extract the document zones to work now on letters :

    WIDTH=400
    RATIO=0.85
    ./bin/extractRect --gray --resize_width=$WIDTH --ratio=$RATIO --backend=directory results/permis_A_A1_redressed/results.csv results/permis_A_A1_redressed-directory-$WIDTH-$RATIO

but we get the same result extracting from original images :

    ./bin/extractRect --gray --resize_width=$WIDTH --ratio=$RATIO $DATA_ROOT/rr_permis_A_A1.csv results/permis_A_A1-directory-$WIDTH-$RATIO

    cp -r results/permis_A_A1-directory-$WIDTH-$RATIO/0 $DATA_ROOT/permis_A_A1_extracted

Here is a code to extract the different lines :

```bash
cd results/permis_A_A1-directory-$WIDTH-$RATIO
cp -r _0 pos-crop
cd pos-crop/
R_H=$(expr $WIDTH*$RATIO/7 |bc)
POS_X=$(expr $WIDTH*0.65/1 |bc)
R_W=$(expr $WIDTH*0.35/1 |bc)
mkdir extracts
for i in *; do
  for j in {0..6} ; do
    POS_Y=$(expr $R_H*$j |bc)
    convert -crop ${R_W}x$R_H+$POS_X+$POS_Y $i extracts/${i/.jpg}-$j.jpg
  done
  #rm $i
done
```

Annotate the letters

    ./bin/annotateRect $DATA_ROOT/permis_A_A1_extracted rr_permis_A_A1_extracted_letters.csv --ratio 1.4 --cross
    #scale down annotation rectangles to size 14x19 (FN+key down)

You have the choice to annotate the letters and the "*", or just the letters. For a better recognition, it is better to annotate the letters only.

    ./bin/annotateRect $DATA_ROOT/permis_A_A1_extracted rr_permis_A_A1_extracted_letters-lettersonly.csv --ratio 1.4 --cross

Extract :

    RATIO=1.4
    WIDTH=18
    NOISE=10
    NOISE_STRIDE=4.0
    ./bin/extractCaptureWindow $DATA_ROOT/rr_permis_A_A1_extracted_letters-lettersonly.csv \
      results/permis_A_A1_img_letters_only_${WIDTH}_${RATIO}_${NOISE}_${NOISE_STRIDE}  \
      --ratio=$RATIO --max=$WIDTH --noise=$NOISE --noise_stride=$NOISE_STRIDE


    ./bin/extractCaptureWindow $DATA_ROOT/rr_permis_A_A1_extracted_letters-lettersonly.csv \
      results/permis_A_A1_img_letters_only_18_$1.4_10_4.0  \
      --ratio=1.4 --max=18 --noise=10 --noise_stride=4.0

[TO DO convert to negatives]


Train position classifier for letters :

    python python/train_net.py python/driving_letters_position 1500

    python python/transform_to_convolution.py python/driving_letters_position/train_val.prototxt python/driving_letters_position/train_val.caffemodel \
      python/driving_letters_position/train_val_featuremap.prototxt python/driving_letters_position/train_val_featuremap.caffemodel

    cp python/driving_letters_position/train_val_featuremap.caffemodel models/driving/position.caffemodel


Other types of driving licenses :

    ./bin/extractRect --gray --resize_width=800 --ratio 0.63 --backend=directory $DATA_ROOT/permis_europe.csv results/permis_europe_redressed-directory-800-0.63

    ./bin/extractRect --gray --resize_width=800 --ratio 0.63 --backend=directory $DATA_ROOT/permis_europe_dos.csv results/permis_europe_dos_redressed-directory-800-0.63

    ./bin/extractRect --gray --resize_width=400 --ratio 0.75 --backend=directory $DATA_ROOT/permis_A.csv results/permis_A_redressed-directory-400-0.75

    ./bin/extractRect --gray $DATA_ROOT/rr_permis_A_A1.csv --offset_x=-1.1 --offset_y=-0.09 -factor_height=1.17  --resize_width=800 results/permis_A_A1_redressed-800-1.17

(retour à ratio 1 grâce à factor_width = 1/0.85 = 1.17)

### Letter Reading


Train the letter classifier :

    python python/train_net.py python/driving_letters_read 1500

    cp python/driving_letters_read/train_val.caffemodel models/driving/read.caffemodel

Annotate further :

    ./bin/annotateLetters python/driving_full_translation_rotation_scale_googlenet models/driving2/train_val_featuremap models/driving.xml $DATA_ROOT/permis_A_A1 results/permis_A_A1_extracted_with_letters

    cp -r results/permis_A_A1_extracted_with_letters $DATA_ROOT/permis_A_A1_extracted_with_letters

    ./bin/annotateRect $DATA_ROOT/permis_A_A1_extracted_with_letters/_/ rr_permis_A_A1_extracted_letters_further.csv --init $DATA_ROOT/permis_A_A1_extracted_with_letters/results.csv --cross

    cp rr_permis_A_A1_extracted_letters_further.csv $DATA_ROOT/rr_permis_A_A1_extracted_letters_further.csv

    ./bin/extractRect $DATA_ROOT/rr_permis_A_A1_extracted_letters_further.csv --gray  results/permis_A_A1_extracted_letters_further


Example of result in DATA_ROOT : permis_A_A1_extracted_with_letters directory and rr_permis_A_A1_extracted_letters_further.csv

Train further

    python python/train_net.py python/driving_letters_read2 5000

    cp python/driving_letters_read2/deploy.prototxt models/driving/read.prototxt
    cp python/driving_letters_read2/train_val.caffemodel models/driving/read.caffemodel

Train model with STN

    python python/train_net.py python/driving_letters_read2_with_stn_daerduoCarey 5000

    cp python/driving_letters_read2_with_stn_daerduoCarey/deploy.prototxt models/driving/read.prototxt
    cp python/driving_letters_read2_with_stn_daerduoCarey/train_val.caffemodel models/driving/read.caffemodel



### Read driving licenses

    ./bin/read Drivinglicense models/driving.xml models/driving/position models/driving/read $DATA_ROOT/permis_A_A1_redressed output_dir

    ./bin/read2 models/types/train_val models/permis_A_A1_redressed-opencv-50-0.85-10.xml models/driving/position models/driving/read $DATA_ROOT/permis_A_A1_redressed output_dir

    ./bin/read2 models/types/train_val models/plates.xml models/plates_letters/deploy models/driving.xml models/driving/position models/driving/read $DATA_ROOT/permis_A_A1_redressed output_dir

    ./bin/read3 models/types/train_val models/plates.xml models/plates_letters/deploy models/driving.xml models/driving/orientation models/driving/position models/driving/read $DATA_ROOT/permis_A_A1 output_dir



# R&D

### Document zone with STN

I will detect the A-D zone.

    ./bin/extractRect --resize_width=150 --ratio=0.85 --noise_rotation=90 --noise_translation=0.5 --noise_zoomout=3 --samples 5 $DATA_ROOT/rr_permis_A_A1.csv results/stn


Check if the results are ok :

    cd results/stn
    ../../bin/annotateRect 0 results.csv --ratio 0.85

![](tutorial/img/stn_1.png) ![](tutorial/img/stn_2.png) ![](tutorial/img/stn_3.png)


    ./bin/extractRect --resize_width=227 --ratio=1 --noise_translation=0.5 --noise_zoomout=3 --samples 15 $DATA_ROOT/rr_permis_A_A1.csv results/stn_translation_scale

    python python/train_net.py python/driving_zones_translation_scale_caffenet 500 python/document_category_caffenet/bvlc_reference_caffenet.caffemodel

Loss is around

    0.03 at 520 iterations
    0.02 at 520
    0.025 at 500
    0.028 at 480
    0.03 at 450
    0.03 at 400
    0.028 at 360
    0.035 at 340
    0.03 at 314
    0.03 at 300
    0.04 at 275
    0.04 at 250
    0.045 at 200
    0.04 at 150
    0.05 at 120
    0.06 at 100
    0.06 at 60
    0.07 at 50
    0.08 at 40
    0.09 at 30


With Alexnet or GoogleNet :

    ./bin/extractRect --resize_width=227 --ratio=1 --noise_translation=0.5 --noise_zoomout=3 --samples 40 $DATA_ROOT/rr_permis_A_A1.csv results/stn_translation_scale-2

    python python/train_net.py python/driving_zones_translation_scale_alexnet 500 ~/technologies/caffe/models/bvlc_alexnet/bvlc_alexnet.caffemodel

    #see the results
    ./bin/localize python/driving_zones_translation_scale_alexnet results/stn_translation_scale/0 output.csv
    ./bin/annotateRect results/stn_translation_scale/0 output.csv -export=output

    python python/train_net.py python/driving_zones_translation_scale_googlenet 500 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel


**With rotations:**

    ./bin/extractRect --resize_width=227 --ratio=1 --noise_rotation=180 --noise_translation=0.5 --noise_zoomout=3 --samples 100 $DATA_ROOT/rr_permis_A_A1.csv results/stn_translation_rotation_scale

    python python/train_net.py python/driving_zones_translation_rotation_scale_alexnet 1000 ~/technologies/caffe/models/bvlc_alexnet/bvlc_alexnet.caffemodel

    ./bin/localize python/driving_zones_translation_rotation_scale_alexnet results/stn_translation_rotation_scale/0 output_r.csv

    ./bin/annotateRect results/stn_translation_rotation_scale/0 output_r.csv -export=output_r

I get a loss of 0.05 after 500 iterations.


    python python/train_net.py python/driving_zones_translation_rotation_scale_googlenet 1000 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel

**Small translations/scales :**


    ./bin/extractRect --resize_width=227 --ratio=1 --noise_translation=0.2 --noise_zoomout=1.5 --noise_zoomin=1.5 --samples 40 $DATA_ROOT/rr_permis_A_A1.csv results/stn_translation_scale-small

    python python/train_net.py python/driving_zones_translation_scale_small_alexnet 500 ~/technologies/caffe/models/bvlc_alexnet/bvlc_alexnet.caffemodel

    ./bin/localize python/driving_zones_translation_scale_small_alexnet results/stn_translation_scale-small/0 output_s.csv

    ./bin/annotateRect results/stn_translation_scale-small/0 output_s.csv -export=output_s

I get a loss of 0.015 after 500 iterations.

With negatives :

    ./bin/extractRect --resize_width=227 --ratio=1 --noise_translation=0.2 --noise_zoomout=1.5 --samples 40 $DATA_ROOT/rr_permis_A_A1.csv results/stn_translation_scale-4 --neg_per_pos=4 --neg_width=0.33




Extraction des permis à l'exact (avec noise gaussien et poivre&sel):

    ./bin/extractRect $DATA_ROOT/rr_permis_A_A1.csv --factor_width=3.1 --factor_height=1.8 --offset_x=-0.05 --offset_y=0.15 --resize_width=227 results/drivinglicenses_solo

    ./bin/extractRect $DATA_ROOT/rr_permis_A_A1.csv --factor_width=3.1 --factor_height=1.8 --offset_x=-0.05 --offset_y=0.15 --resize_width=227 --pepper_noise=0.1 --gaussian_noise=30 --samples=10 results/drivinglicenses_solo3

    cp -r $DATA_ROOT/negatives results/drivinglicenses_solo3/1
    rm results/drivinglicenses_solo3/1/negatives.txt
    for i in results/drivinglicenses_solo3/1/*; do echo "${i:30},1,0" >> results/drivinglicenses_solo3/results.csv; done

    python python/train_net.py python/driving_classifier_googlenet 200 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel

which gives around 0.0001.





Extraction des zones avec noise en translation, rotation et échelle :

    ./bin/extractRect $DATA_ROOT/rr_permis_A_A1.csv --noise_rotation=40 --noise_translation=0.2 --noise_zoomout=1.5 --noise_zoomin=1.5 --factor_width=3.1 --factor_height=1.8 --offset_x=-0.05 --offset_y=0.15 --resize_width=227 --pepper_noise=0.1 --gaussian_noise=30 --samples=100 results/drivinglicenses_solo_recal

    ./bin/extractRect $DATA_ROOT/rr_permis_A_A1.csv --noise_rotation=40 --noise_translation=0.2 --noise_zoomout=1.5 --noise_zoomin=1.5 --factor_width=1.53 --factor_height=1.8 --offset_x=-0.05 --offset_y=0.15 --resize_width=227 --pepper_noise=0.01 --gaussian_noise=30 --samples=100 results/drivinglicenses_solo_recal_square


    python python/train_net.py python/driving_detector_googlenet 1500 ~/technologies/caffe/models/bvlc_googlenet/bvlc_googlenet.caffemodel

    ./bin/localize python/driving_detector_googlenet results/drivinglicenses_solo_recal_square/0 tttt

    ./bin/annotateRect tttt/_/ tttt/results.csv

    ./bin/localize2 python/driving_full_translation_rotation_scale_googlenet/ python/driving_detector_googlenet $DATA_ROOT/permis_A_A1 output_full_googlenet9

    ./bin/annotateRect output_full_googlenet9/_/ output_full_googlenet9/results.csv -export=tttttt
