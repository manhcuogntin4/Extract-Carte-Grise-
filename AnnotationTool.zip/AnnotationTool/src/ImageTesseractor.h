#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>

#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "Utils.h"

using namespace cv;
using std::string;

class ImageTesseractor
{

public:

    ImageTesseractor( char* lang);
    char readRectFirst( WorkImage image, Rect r );
    char readRect( WorkImage image, Rect r );
    std::string readRects( WorkImage image, vector<cv::Rect> & orderedRects );
    tesseract::TessBaseAPI *api;

};
