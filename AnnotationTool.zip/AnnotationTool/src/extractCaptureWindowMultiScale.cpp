#include <gflags/gflags.h>
#include <glog/logging.h>
#include <google/protobuf/text_format.h>
//#include <leveldb/db.h>
//#include <leveldb/write_batch.h>
#include <lmdb.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"


#define PI 3.14159265

#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <fstream>

using namespace cv;
using namespace std;

#include <fstream>  // NOLINT(readability/streams)
#include <string>

#include "caffe/proto/caffe.pb.h"
#include "Utils.h"

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

DEFINE_string(backend, "rectangle", "The backend format for storing the result [rectangle|capturewindow]");
// DEFINE_int32(width, 100, "The window width [default:400]");
DEFINE_int32(factor, 1, "The number of negatives per positive [default:3]");
DEFINE_int32(max, 400, "The max scale for capture window width. [default:400]");
DEFINE_int32(min, 160, "The min scale for capture window width. [default:160]");
DEFINE_int32(scales, 3, "The number of width scales. [default:3]");
DEFINE_double(ratio, 1.0, "The ratio of capture window height/width [default:1.0]");
DEFINE_bool(rotated, false, "The format : Rect or RotatedRect [Default : false]");
DEFINE_bool(correct, false, "Correct the ratio of the input rectangle [Default : false]");

uint32_t swap_endian(uint32_t val) {
    val = ((val << 8) & 0xFF00FF00) | ((val >> 8) & 0xFF00FF);
    return (val << 16) | (val >> 16);
}

int get_scores( int center_x, int center_y, int width_min, int width_max, int numscales, float positive_threshold, float negative_threshold, float ratio, Rect rr, vector<Rect> & ss, vector<float> & ss_iou  ) {
  cout << "Scores for " << rr << " with (" << center_x << "," << center_y << ")" << endl; ;

  int i = 0;
  int arg_max = 0;
  float current_max = -10000000.0;
  int number_above_threshold = 0;

  int step = ( width_max - width_min ) / (numscales - 1) ;

  cout << "Width min " << width_min << " ; width max : " << width_max << " ; steps : " << step << endl;
  for(int ss_w = width_min ; ss_w < width_max + 1; ss_w += step  ) {
    int ss_h = ss_w * ratio;
    Rect ss_r (  Point(center_x - floor( ((float)ss_w) / 2.0), center_y - floor( ((float)ss_h) / 2.0) ), Size(ss_w,ss_h) );
    ss.push_back( ss_r );

    // compute Intersection over Union with plate rr
    float iou = ((float)(ss_r & rr).area()) / ((float)(ss_r | rr).area());
    ss_iou.push_back( iou );
    // cout << "," << iou << endl;

    if(iou > current_max ) {
      arg_max = i;
      current_max = iou;
    }

    if(iou > positive_threshold)
      number_above_threshold ++;

    cout << "," << (iou > 0.7) + 2 * (iou < 0.3);
    //cout << "BR : " << rr.tl() << " -> " << rr.br() << endl;

    //cout << "iou "  << ((float)(ss_r & rr).area()) << " - " << ((float)(ss_r | rr).area()) << endl;
    // cout << "," << (iou > 0.7) + 2 * (iou < 0.3);
    // cout << "," << iou << endl;
    i++;
    // cout << "Rectangle : " << ss_r << " - area inter " << (ss_r & rr).area() << " - area union " << (ss_r | rr).area() << " - classe : " << (iou > 0.7) + 2 * (iou < 0.3) << endl;
  }

  cout << endl;
  cout << "Above threshold : " << number_above_threshold << endl;
  if( current_max > positive_threshold  ) {
    cout << "Class : " << arg_max << endl;
    return arg_max;
  } else if( current_max < negative_threshold ) {
    cout << "Class : " << numscales << endl;
    return numscales;
  } else {
    cout << "Class : " << numscales << endl;
    return numscales +1;
  }

}

int get_scores( int center_x, int center_y, int width_min, int width_max, int numclasses, float positive_threshold, float negative_threshold, float ratio, RotatedRect rr, vector<Rect> & ss, vector<float> & ss_iou  ) {
  return 0;
//   int widths [numclasses];
//   cout << "Scores : ";
//   int orientation = 0;
//   //for(int orientation = -5 ; orientation < 6 ; orientation += 5)
//   for(int ss_w = width_min ; ss_w < width_max + 1; ss_w += ( width_max - width_min ) / numclasses  ) {
//     int ss_h = ss_w * ratio;
//
//     RotatedRect ss_r2 ( Point(center_x,center_y), Size(ss_w,ss_h), orientation );
//     ss.push_back( ss_r2 );
// //    Rect ss_r (  Point(center_x - floor( ((float)ss_w) / 2.0), center_y - floor( ((float)ss_h) / 2.0) ), Size(ss_w+1,ss_h+1) );
//     // ss.push_back( ss_r );
//
//     // compute Intersection over Union with plate rr
//
//     // Rect rr1 = rr + Size(1,1);
//     // float iou = ((float)(ss_r & rr).area()) / ((float)(ss_r | rr).area());
//     // ss_iou.push_back( iou );
//     // cout << "," << iou << endl;
//     //cout << "," << (iou > 0.7) + 2 * (iou < 0.3);
//     //cout << "BR : " << rr.tl() << " -> " << rr.br() << endl;
//
//     // RotatedRect ss_r2 ( Point2f(center_x ,center_y), Size2f(ss_w, ss_h), 0 );
//     // RotatedRect rr2 ( Point( getCenterX(rr)  , getCenterY(rr) ), rr.size()  , 0 );
//
//     //cout << "iou "  << ((float)(ss_r & rr).area()) << " - " << ((float)(ss_r | rr).area()) << endl;
//     // float ff =  ;
//     float iou = intersectionOverUnion(ss_r2, rr );
//     cout << "," << (iou > 0.7) + 2 * (iou < 0.3);
//     // cout << "," << iou << endl;
//     ss_iou.push_back( iou );
//     // cout << iou << "/" << ff << endl;
//
//     // cout << "Rectangle : " << ss_r << " - area inter " << (ss_r & rr).area() << " - area union " << (ss_r | rr).area() << " - classe : " << (iou > 0.7) + 2 * (iou < 0.3) << endl;
//   }
//   cout << endl;
}

void convert_dataset(const char* csv_filename, const char* db_path, int nb_negatives_per_positive, int cols, int min_w, int numscales, double ratio, const string& db_backend, bool rotated, bool correct) {
  const int rows = cols * ratio;

  // Open files
  std::vector<std::vector<std::string> > input;
  readCSV( csv_filename , input);

  string base_path = getbase(csv_filename);
  cout << "Base path: " << base_path << endl;

  cout << "Capture window : " << cols << " x " << rows << " (ratio: " << ratio << ")" << endl;
  cout << "Number of scales : " << numscales << endl;
  cout << "Number of classes : " << numscales + 2 << " : " << endl;
  cout << "  Positive window classes : O to " << (numscales-1) << endl;
  cout << "  Negative window class : " << numscales << endl;
  cout << "  No-neg No-pos window class : " << numscales+1 << endl;
  cout << "Sample negative windows per positive: " << nb_negatives_per_positive << endl;
  //cout << "Windows resized to : " << target_width << " x " << target_height << endl;

  std::ofstream outfile, outfile_neg;

  //statistics
  double average_width = 0;
  double average_height = 0;
  int average_count = 0;
  int max_width = 0;
  int min_width = 1000000000;
  int max_height = 0;
  int min_height = 1000000000;
  int min_orientation = 90;
  int max_orientation = -90;

  // initiate directories or db
  if(db_backend == "capturewindow") {
    // create directory for images
    LOG(INFO) << "Creating directory " << db_path;
    CHECK_EQ(mkdir(db_path, 0744), 0)
        << "mkdir " << db_path << " failed";
    outfile.open( std::string( db_path ) + "/results.csv", std::ios_base::app);
  } else if(db_backend == "rectangle") {
    // create directories for positive and negative images
    string dir_paths [5] = { string(db_path), string(db_path) + "/pos", string(db_path) + "/neg", string(db_path) + "/pos/img", string(db_path) + "/neg/img" };
    for(int i = 0 ; i < 5 ; i ++) {
      const char * dir_path = dir_paths[i].c_str();
      LOG(INFO) << "Creating directory " << dir_path;
      CHECK_EQ(mkdir(dir_path, 0744), 0)
          << "mkdir " << db_path << " failed";
    }
    outfile.open( std::string( db_path ) + "/pos/info.dat", std::ios_base::app);
    outfile_neg.open( std::string( db_path ) + "/neg/info.dat", std::ios_base::app);
  } else {
    LOG(FATAL) << "Unknown db backend " << db_backend;
  }

  // Storing to db
  char label;
  char* pixels = new char[rows * cols];
  int count = 0;
  const int kMaxKeyLength = 10;
  char key_cstr[kMaxKeyLength];
  string value;

  Datum datum;
  //Datum datum2;
  datum.set_channels(1);
  datum.set_height(rows);
  datum.set_width(cols);
  // datum.set_w(cols);
  // datum.set_h(rows);
  LOG(INFO) << "Rows: " << rows << " Cols: " << cols;
  int item_id = 0;


  for(int cursor = 0; cursor < input.size(); cursor++) {
    int res_x = stoi(input[cursor][2]);
    int res_y = stoi(input[cursor][3]);
    int res_w = stoi(input[cursor][4]);
    int res_h = stoi(input[cursor][5]);

    Mat image = imread(base_path + input[cursor][0], CV_LOAD_IMAGE_COLOR);   // Read the file
    if(! image.data )                              // Check for invalid input
    {
        std::cout <<  "Could not open or find the image " << base_path + input[cursor][0] << std::endl ;
        return ;
    } else {

      int height = image.rows, width = image.cols, area = height * width, channel = image.channels();

      Mat gray_image;//, threshold_image;
      cvtColor(image,gray_image,CV_BGR2GRAY);
      // adaptiveThreshold(gray_image,threshold_image,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,11,12);

      cout << "Item " << item_id << ": " << input[cursor][0] << endl;

      //extract Rect
      Rect rr_a( res_x - res_w / 2.0 , res_y - res_h / 2.0 , res_w, res_h );
      if(correct)
        correct_ratio ( rr_a, ratio );
      int center_x = getCenterX(rr_a);
      int center_y = getCenterY(rr_a);

      //extract RotatedRect
      int orient = 0;
      if( rotated ) orient = stoi(input[cursor][6]);
      Size2f s;
      if( correct  )
        s = correct_ratio(res_w, res_h, ratio);
      else
        s = Size2f(res_w, res_h);
      RotatedRect rr_a_rot( Point2f(res_x , res_y ) , s, orient );
      if(rotated) {
        rr_a = rr_a_rot.boundingRect();
        center_x = rr_a_rot.center.x ;
        center_y = rr_a_rot.center.y ;
      }

      // Extract positive and negative rectangles from images
      // - for opencv training :
      vector<Rect> _ss ;
      vector<float> _ss_iou;
      // - for caffe training :
      vector<Point> points;
      vector<int> classes;
      vector<Point> points_neg;
      vector<float> scales;

        // // From the plate center
        // Rect rc ( Point(center_x - cols/2,center_y - rows/2), Size(cols,rows) );
        // if( is_in_image( rc, image ) ) {
        //
        //   int s = get_scores( center_x, center_y, min_w, cols, numscales, 0.7, 0.3, 0.3, rr_a, _ss, _ss_iou );
        //
        //   if( s < numscales ) {
        //     classes.push_back( s );
        //     points.push_back( Point(center_x,center_y) );
        //     scales.push_back( 1.0 );
        //   }
        //
        //   if( s == numscales ) {
        //     points_neg.push_back( Point(center_x,center_y) );
        //   }
        //
        // } else cout << "CENTER TOO CLOSE TO BORDER" << endl;


        // In order to balance the dataset between all classes,
        // find positives by rescaling the image,
        // draw 'numscales' rescaling randomly.
      int range = cols - min_w;
      float width_ratio = ((float)min_w) / ((float)cols) ;
      float start = ((float)min_w) - 0.5 * ((float)range);
      float end = ((float)cols) + 0.2 * ((float)range);
      int step = range / (numscales - 1) ;
      int ss_w = min_w - step;
      for(int j = 0; j < numscales ; j++  ) {
        ss_w += step;
        float rescaling = ((float)rr_a.size().width) / ((float)ss_w) ;

        //RANDOM SCALE 1
        // // proba entre 0 et 1
        // float rand_proba = static_cast <float> (rand()) /( static_cast <float> (RAND_MAX)  ) * ( 1.0 + 1.0 / ( ((float)numscales) - 1.0 ) )  - 1.0 / ( 2.0 * (((float)numscales) -1.0)  ) ;
        // cout << "rand proba " << rand_proba << endl;
        // // proba entre -0.3 et 1.3
        // float rescaling =  sqrt( (1.0 - width_ratio) * rand_proba + width_ratio );

        //RANDOM SCALE 2
        // // draw a width between start and end
        // float rand_width = start + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(end-start)));
        // // compute scale
        // float rescaling = ((float)rr_a.size().width) / rand_width;
        int min_w_rescaled = rescaling * min_w;
        int max_w_rescaled = rescaling * cols;
        int max_h_rescaled = rescaling * rows;
        cout << "Scale : " << rescaling << endl;

        if( is_in_image( Rect ( Point(center_x - max_w_rescaled/2,center_y - max_h_rescaled/2), Size(max_w_rescaled,max_h_rescaled) ), image ) ) {
          int s ;
          if(!rotated)
            s = get_scores( center_x, center_y, min_w_rescaled, max_w_rescaled, numscales, 0.7, 0.3, ratio, rr_a, _ss, _ss_iou );
          else
            s = get_scores( center_x, center_y, min_w_rescaled, max_w_rescaled, numscales, 0.7, 0.3, ratio, rr_a_rot, _ss, _ss_iou );

          if( s < numscales ) {
            classes.push_back( s );
            points.push_back( Point(center_x,center_y) );
            scales.push_back( rescaling );
          }
          if( s == numscales ) {
            points_neg.push_back( Point(center_x,center_y) );
          }
        }
      }

      // From other points randomly drawn in the image
      for( int j = 0 ; j < nb_negatives_per_positive ; j ++) {
        // srand (time(NULL));
        int ss_x1 = rand() % (width - cols)  ;
        int ss_y1 = rand() % (height  - rows) ;

        int s ;
        if(!rotated)
          s = get_scores( ss_x1+ cols/2, ss_y1+ rows/2, min_w, cols, numscales, 0.7, 0.3, ratio, rr_a, _ss, _ss_iou );
        else
          s = get_scores( ss_x1+ cols/2, ss_y1+ rows/2, min_w, cols, numscales, 0.7, 0.3, ratio, rr_a_rot, _ss, _ss_iou );


        if( s < numscales ) {
          points.push_back( Point(ss_x1 + cols/2, ss_y1+rows/2) ) ;
          classes.push_back( s );
          scales.push_back( 1.0 );
        }

        if( s == numscales ) {
          points_neg.push_back( Point(ss_x1 + cols/2, ss_y1+rows/2) ) ;
          cout << "Neg " << Point(ss_x1 + cols/2, ss_y1+rows/2) << endl;
        }

      }


        // Save results for Caffe
        if(db_backend == "capturewindow") {

          // add K * nb_positives  negatives in the array
          int K2 = min(nb_negatives_per_positive * points.size(), points_neg.size());
          std::random_shuffle ( points_neg.begin(), points_neg.end() );
          for(int i = 0; i < K2 ; i ++ ) {
            points.push_back( points_neg[i] );
            classes.push_back ( numscales );
            scales.push_back( 1.0 );
          }

          bool dejavu_classes [ numscales +1 ];

          for(int i = 0; i < numscales +1  ; i ++)
            dejavu_classes[i] = false;

          for(int i = 0 ; i < points.size() ; i++) {

            if( dejavu_classes[classes[i]] )
              continue;
            else dejavu_classes[classes[i]] = true;

            Rect extr ( points[i] - Point( ((float)cols) / 2.0 * scales[i], ((float)rows) / 2.0 * scales[i]), Size(((float)cols) * scales[i],((float)rows) * scales[i]));
            cout << "Extract " << extr << endl;
            cout << "Dim " << width << "," << height << endl;
            Mat extracted_image = gray_image( extr );
            //Mat resized_extracted_image;
            //resize(extracted_image,resized_extracted_image,Size(target_width,target_height));
            string output_path = string(db_path) + "/" + std::to_string(item_id) +"_" + std::to_string(i) +"_" + std::to_string(classes[i]) + ".png" ;
            imwrite( output_path , extracted_image );
            outfile << output_path << " " << std::to_string(classes[i]) << endl;
            outfile.flush();
            extracted_image.release();
            //resized_extracted_image.release();
          }

          for(int i = 0 ; i < _ss.size(); i++)
              displayRectangle(image, _ss[i]);
          if(!rotated)
            displayRectangle(image,rr_a);
          else
            displayRotatedRectangle(image, rr_a_rot);

          imwrite(std::string(db_path) + "/_" + std::to_string(item_id) + ".png" , image );
          item_id ++;

        } else if(db_backend == "rectangle") {

          if( is_in_image(rr_a, image)) { // && rr_a.width > target_width

              // save a positive
              string output_path =  "img/" + std::to_string(item_id) + ".jpg" ;
              Mat extracted_image;
              if(!rotated)
                extracted_image = gray_image( rr_a );
              else
                extracted_image = extractRotatedRect( gray_image, rr_a_rot );
              //Mat resized_extracted_image;
              //resize(extracted_image,resized_extracted_image,Size(target_width,target_height));
              imwrite( string(db_path) + "/pos/" + output_path , extracted_image );
              outfile << output_path << " 1 " << rr_a.tl().x << " " << rr_a.tl().y << " " << rr_a.size().width << " " << rr_a.size().height << endl;
              outfile.flush();
              item_id ++;
              extracted_image.release();
              //resized_extracted_image.release();

              // save negatives
              vector<Rect> ss_neg ;
              for(int i = 0 ; i < _ss.size(); i++)
                  if( _ss_iou[i] < 0.3 && is_in_image(_ss[i], image ) )
                    ss_neg.push_back( _ss[i] );
              std::random_shuffle ( ss_neg.begin(), ss_neg.end() );
              for(int i = 0; i < std::min(nb_negatives_per_positive, (int)ss_neg.size()) ; i ++ ) {
                cout << ss_neg[i] << endl;
                string output_path =  "img/" + std::to_string(item_id) + ".jpg" ;
                Mat extracted_image = gray_image( ss_neg[i] );
                //Mat resized_extracted_image;
                //resize(extracted_image,resized_extracted_image,Size(target_width,target_height));
                imwrite( string(db_path) + "/neg/" + output_path , extracted_image );
                outfile_neg << output_path << endl;
                outfile_neg.flush();
                item_id ++;
                extracted_image.release();
                //resized_extracted_image.release();
              }
            }

       } else {
         LOG(FATAL) << "Unknown db backend " << db_backend;
       }

        gray_image.release();
      }

      image.release();
  }

  // close
  if(db_backend == "rectangle")
    outfile.close();

  delete pixels;

}

// MAIN FUNCTION
int main(int argc, char** argv) {
#ifndef GFLAGS_GFLAGS_H_
  namespace gflags = google;
#endif

  gflags::SetUsageMessage("This script extracts rectangles to\n"
        "the format used by Caffe or OpenCV to train data.\n"
        "Usage:\n"
        "    extractCaptureWindowMultiScale [FLAGS] input_csv_file output_dir"
        "\n");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  const string& db_backend = FLAGS_backend;
  const double& ratio = FLAGS_ratio;
  // const int& width = FLAGS_width;
  // const int& height = width * ratio ;
  const int& factor = FLAGS_factor;
  const int& max = FLAGS_max;
  const int& min = FLAGS_min;
  const int& scales = FLAGS_scales;
  const bool& rotated = FLAGS_rotated;
  const bool& correct = FLAGS_correct;

  if (argc != 3) {
    gflags::ShowUsageWithFlagsRestrict(argv[0],
        "examples/mnist/convert_mnist_data");
  } else {
    google::InitGoogleLogging(argv[0]);
    convert_dataset(argv[1], argv[2], factor, max, min, scales, ratio, db_backend, rotated, correct);
  }
  return 0;
}
