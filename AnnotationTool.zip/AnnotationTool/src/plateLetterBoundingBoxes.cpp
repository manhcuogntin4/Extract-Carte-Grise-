#include "Plate.h"

int main( int argc, char** argv )
{
    if( argc != 3)
    {
     cout <<" Usage: ./annotate input output.csv" << endl;
     return -1;
    }

    Plate plate;
    std::ofstream outfile;
    outfile.open( std::string(argv[2]), std::ios_base::app);

    struct dirent *entry;
    int ret = 1;
    DIR *dir;
    dir = opendir (argv[1]);
    while ((entry = readdir (dir)) != NULL) {
      printf("Annotating %s\n",entry->d_name);
      plate.annotateImage( std::string(argv[1]) + "/" + std::string(entry->d_name), &outfile  );
    }
    outfile.close();
    return 0;
}
