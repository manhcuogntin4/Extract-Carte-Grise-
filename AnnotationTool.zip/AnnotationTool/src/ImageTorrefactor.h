#include <caffe/caffe.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iosfwd>
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include "Utils.h"

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

/* Pair (label, confidence) representing a prediction. */
typedef std::pair<string, float> Prediction;

class ImageTorrefactor {
 public:
  ImageTorrefactor(const string& model_file, const string& trained_file);
  std::vector<Prediction> Classify(const cv::Mat& img, int N = 5, const char * dict = legal);
  std::vector<Prediction> Classify(Mat gray_image, int x, int y, int w, int h, int N = 5);
  RotatedRect Localize(Mat full_image);
  std::string readRects(Mat gray_image, vector<cv::Rect> & orderedRects, int threshold);
  std::vector<float> Predict(const cv::Mat& img);
  int output_width ();
  int output_height ();
  void reshape(int width, int height);
  cv::Size Dimensions();

 private:
  void SetMean(const string& mean_file);
  void WrapInputLayer(std::vector<cv::Mat>* input_channels);
  void Preprocess(const cv::Mat& img,std::vector<cv::Mat>* input_channels);

 private:
  boost::shared_ptr<Net<float> > net_;
  cv::Size input_geometry_;
  int num_channels_;
  cv::Mat mean_;
  std::vector<string> labels_;
};
