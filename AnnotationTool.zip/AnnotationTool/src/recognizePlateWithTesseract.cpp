#include "ImageTesseractor.h"
#include <sys/stat.h>
#include <glog/logging.h>

int main(int argc, char** argv)
{

  if( argc != 4)
  {
   cout <<" Usage: ./recognizePlateWithTesseract input_dir eng output_dir" << endl;
   return -1;
  }

  google::InitGoogleLogging(argv[0]);

  CHECK_EQ(mkdir(argv[3], 0744), 0)
      << "mkdir " << argv[3] << "failed";

  ImageTesseractor tesseractor (argv[2]);
  CascadeClassifier* plate_cc = new CascadeClassifier(string("models/plates.xml")) ;

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[1]);
  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);
    WorkImage image ( std::string(argv[1]) + "/" + std::string(entry->d_name) );
    if(image.ok) {
      vector<cv::Rect> plateZone;
      vector<vector<cv::Point> > all_contours;
      detectRectsAndContours(plate_cc,image, plateZone, all_contours);

      vector<cv::Rect> orderedRects;  vector<vector<cv::Point> > orderedContours;
      if(plateZone.size()>0 )
        extractRect(image,plateZone[0], all_contours,orderedContours,orderedRects);

      std::string text = tesseractor.readRects( image, orderedRects );

      displayText(image.image,text);
      displayRects(image.image,plateZone);
      imwrite( std::string(argv[3]) + "/" + std::string(entry->d_name) , image.image );
    }
  }
  return 0;
}
