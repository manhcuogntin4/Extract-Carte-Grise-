#include "Utils.h"
#include "ImageTorrefactor.h"
#include <glog/logging.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{

  if( argc != 2)
  {
   cout <<" Usage: ./bin/test_sp input_dir" << endl;
   return -1;
  }

  ImageTorrefactor * reading_classifier = new ImageTorrefactor(string("python/driving_letters_read2_with_stn_daerduoCarey/deploy.prototxt"),string("python/driving_letters_read2_with_stn_daerduoCarey/train_val.caffemodel"));

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[1]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  int count = 0 ;

  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);

    WorkImage img(std::string(argv[1]) + "/" + std::string(entry->d_name) );
    if(img.ok) {
      count ++;
      cout << "Image size " << img.height << "x" << img.width << endl;
      // for(int j = 0; j < 6; j++)
      //   cout << "dim " << multiplyBy(img.full_image,0.00390625).at<float>(0,j) << endl;
      std::vector<float> output = reading_classifier->Predict(multiplyBy(img.full_image,0.00390625)) ;
      cout << output.size() << endl;
      std::vector<int> maxN = Argmax(output, 12);
      cout << "Max : " << maxN[0] << endl;


    }
    if(count >= 50) break;

  }
  return 0;
}
