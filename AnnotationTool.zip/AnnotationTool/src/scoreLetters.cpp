#include "ImageTesseractor.h"
#include "ImageTorrefactor.h"

int main(int argc, char** argv )
{

  if( argc < 3 )
  {
   std::cout <<" Usage: ./scoreLetters tesseract file.csv" << std::endl;
   std::cout <<" Usage: ./scoreLetters caffe file.csv deploy.prototxt model.caffemodel" << std::endl;
   return -1;
  }

  string technology = string(argv[1]);

  if( technology == "caffe" )
      if( argc != 5 ) {
        std::cout <<" Usage: ./scoreLetters caffe file.csv deploy.prototxt model.caffemodel" << std::endl;
        return -1;
      }

  char lng[10] = "eng";
  // char lng[10] = "lpfra";
  ImageTesseractor tesseractor ( lng );
  ImageTorrefactor classifier(argv[3], argv[4]); //mean_file, label_file

  std::vector<std::vector<std::string> > input;
  readCSV( argv[2] , input);


  int count =0 ;
  int total = 0;

  for(int cursor = 0; cursor < input.size(); cursor++) {
    WorkImage image ( input[cursor][0] );
    int res_x = stoi(input[cursor][2]) * image.factor;
    int res_y = stoi(input[cursor][3]) * image.factor;
    int res_w = stoi(input[cursor][4]) * image.factor;
    int res_h = stoi(input[cursor][5]) * image.factor;

      if(image.ok) {
        total ++;
        if(technology == "tesseract") {
          char r = tesseractor.readRect( image, Rect(res_x, res_y, res_w, res_h ));
          if(r == input[cursor][1][0]) count ++; else cout << "(Mismatch) " << input[cursor][0] << endl ;
          cout << input[cursor][1] << ":"  <<  r << endl;

        } else if( technology == "caffe") {
          std::vector<Prediction> predictions = classifier.Classify(image.gray_image, res_x, res_y, res_w, res_h);

          cout << input[cursor][1] << ":"  << endl;
          if((predictions.size() > 0) && ((predictions[0].first[0]) == (char) input[cursor][1][0]))
            count ++;
          else cout << "(Mismatch) " <<  input[cursor][0]  << endl;
          for (size_t i = 0; i < predictions.size(); ++i) {
            Prediction p = predictions[i];
            std::cout << std::fixed << std::setprecision(4) << p.second << " - \""
                      << p.first << "\"" << std::endl;
          }
        } else cout << "Unrecognized technology" << endl;

      }
      image.release();
      cout << "Score : " << count;
      cout << " sur " << total << endl;
  }
}
