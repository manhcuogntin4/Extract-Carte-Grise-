#include "DrivingLicense.h"
#include <glog/logging.h>
#include <sys/stat.h>

int REGISTRATION_CARD = 2;
int DRIVING_LICENSE = 1;
int LICENSE_PLATE = 0;

int main(int argc, char** argv)
{

  if( argc != 10)
  {
   cout <<" Usage: ./read2 type_model_prefix plate.xml plate_letters_model_prefix driving.xml driving_position_model_prefix position_model_prefix read_model_prefix input_dir output_dir" << endl;
   return -1;
  }

  //Caffe::set_mode(Caffe::CPU);

  CHECK_EQ(mkdir(argv[9], 0744), 0)
      << "mkdir " << argv[9] << " failed";

  //TYPE
  ImageTorrefactor * type_classifier = new ImageTorrefactor( string(argv[1]) + string(".prototxt"),string(argv[1]) + string(".caffemodel"));

  //PLATES
  CascadeClassifier* plate_cc = new CascadeClassifier(string(argv[2])) ;
  ImageTorrefactor * plate_letters_classifier = new ImageTorrefactor(string(argv[3]) + string(".prototxt"),string(argv[3]) + string(".caffemodel"));

  //DRIVING
  CascadeClassifier* cc = new CascadeClassifier(string(argv[4])) ;
  ImageTorrefactor * orientation_localizer = new ImageTorrefactor( string(argv[5]) + string(".prototxt"),string(argv[5]) + string(".caffemodel"));
  ImageTorrefactor * positioning_classifier = new ImageTorrefactor(string(argv[6]) + string(".prototxt"),string(argv[6]) + string(".caffemodel"));
  ImageTorrefactor * reading_classifier = new ImageTorrefactor(string(argv[7]) + string(".prototxt"),string(argv[7]) + string(".caffemodel"));


  std::ofstream outfile;
  outfile.open( (std::string(argv[9]) + "/results.csv").c_str(), std::ios_base::app);

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[8]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);
    std::string path = std::string(argv[8]) + "/" + std::string(entry->d_name);
    string output_path = string(argv[9]) + "/" + std::string(entry->d_name);

    Mat full_image = imread(path, CV_LOAD_IMAGE_COLOR), image;
    if(!! full_image.data )                              // Check for invalid input
    {

      resize(full_image,image,Size(227,227),0,0,INTER_AREA);
      full_image.release();
      cout << "Detecting type : " ;

      std::vector<float> output = type_classifier->Predict(image);
      // cout << output[0] << "," << output[1] << "," << output[2] << endl;
      std::vector<int> maxN = Argmax(output, 1);
      cout << "Result :" << maxN[0] << endl;
      image.release();

      if( maxN[0] == LICENSE_PLATE ) {
        cout << "LICENSE PLATE" << endl;
        WorkImage image ( path );
        vector<cv::Rect> plateZone;
        vector<vector<cv::Point> > all_contours;
        detectRectsAndContours(plate_cc,image, plateZone, all_contours);

        vector<string> textV;

        for(int j = 0 ; j < plateZone.size(); j++ ) {
          vector<cv::Rect> orderedRects;  vector<vector<cv::Point> > orderedContours;
          extractRect(image,plateZone[j], all_contours,orderedContours,orderedRects);
          std::string text = plate_letters_classifier->readRects( image.gray_image , orderedRects, 2000 );
          textV.push_back(text);
        }

        // for( int i = 0 ; i < orderedRects.size() ; i ++) {
        //   displayRectangle(image.image, orderedRects[i]);
        displayRects(image.image,plateZone);

        int textmax = 0;
        int argtextmax = 0;
        for (int i = 0 ; i < textV.size() ; i ++ ) {
          if(textV[i].length() > textmax)
            {
              textmax = textV[i].length();
              argtextmax = i;
             }
        }

        if(textV.size() > 0) {
          displayText(image.image,textV[argtextmax]);
          outfile << path << "," << textV[argtextmax] << endl;
        } else outfile << path << "," << endl;
        outfile.flush();

        imwrite(output_path , image.image );
        imwrite( output_path.replace(output_path.end()-4,output_path.end(),"-2.jpg") , image.threshold_image );
      // }
      } else if (maxN[0] == REGISTRATION_CARD ) {

        cout << "REGISTRATION CARD" << endl;

      } else {
        cout << "DRIVING LICENSE" << endl;
        DrivingLicense dl ( std::string(argv[8]) + "/" + std::string(entry->d_name) );
        if( dl.ok ) {
          dl.resize_original(1500);
          dl.orientate(orientation_localizer);
          imwrite(string(argv[9]) + "/" + std::string(entry->d_name) + ".jpg" , dl.image);
          cout << "  Find zones" << endl;
          dl.findZones(cc);
          for(int i = 0 ; i < dl.zones.size(); i++) {
            cout << "  Zone " << i << endl;
            dl.compute_lines(positioning_classifier, dl.zones[i]);
            dl.compute_letter_positions(positioning_classifier);
            std::string res; float score;
            dl.read_letters(reading_classifier, res, score);
            cout << "  -> Max : " << score << " - " << res << endl;
            dl.write_zone(string(argv[9]) + "/" + std::string(entry->d_name) + std::to_string(i) + ".jpg");
          }
          dl.release();
        }
      }

    }

  }
  outfile.close();
  return 0;
}
