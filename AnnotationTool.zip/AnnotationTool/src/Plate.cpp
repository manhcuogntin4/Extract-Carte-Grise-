#include "Plate.h"

Plate::Plate ()
{
  _threshold_ = 1;
  nbCluster = 3;
}

void Plate::annotateImage ( std::string path, std::ofstream * output ) {

  cout << path << endl;
  WorkImage image (path);

  if(image.ok) {

    // extract contours
    vector<Rect> orderedRects;
    vector<Rect> plateZone;
    vector<vector<cv::Point> > all_contours;
    vector<vector<Point> > orderedContours;
    CascadeClassifier* plate_cc = new CascadeClassifier(string("models/plates.xml")) ;

    detectRectsAndContours(plate_cc,image, plateZone, all_contours);
    if( plateZone.size() > 0 )
      extractRect(image,plateZone[0], all_contours,orderedContours,orderedRects);

    for( int j = 0 ; j < orderedRects.size() ; j ++ ) {
        // create a temp image
        Mat image2 ;
        image.image.copyTo(image2);
        double orientation =  getOrientation( orderedContours[j], image2 ) ;
        int k;
        int index_slash = string(path).substr(0,string(path).find_last_of("/\\") ).find_last_of("/\\");
        *output << path.substr(index_slash+1) << "," << (char) k << "," << ((float) getCenterX(orderedRects[j]) ) / image.factor << "," << ((float) getCenterY(orderedRects[j]) )  / image.factor << "," << ((float)orderedRects[j].size().width) / image.factor << "," << ((float)orderedRects[j].size().height) / image.factor << "," << orientation << endl;
        (*output).flush();
        image2.release();
      }
    }
    image.release();
}
