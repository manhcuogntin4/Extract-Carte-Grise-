#include <glog/logging.h>
#include <sys/stat.h>
#include "Utils.h"
#include "ImageTorrefactor.h"
#include <math.h>

#define PI 3.14159265

int main(int argc, char** argv)
{

  if( argc != 5)
  {
   cout <<" Usage: ./localize position_model_prefix precision_position_model_prefix input_dir output" << endl;
   return -1;
  }

  CHECK_EQ(mkdir( argv[4] , 0744), 0)
    << "mkdir " << argv[4] << " failed";
  mkdir( (std::string(argv[4]) + "/_").c_str(), 0744);

  std::ofstream outfile;
  outfile.open(std::string(argv[4]) + "/results.csv", std::ios_base::app);

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[3]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  Caffe::set_mode(Caffe::CPU);

  ImageTorrefactor * localizer = new ImageTorrefactor( string(argv[1]) + string("/deploy.prototxt"),string(argv[1]) + string("/train_val.caffemodel"));
  ImageTorrefactor * precise_localizer = new ImageTorrefactor( string(argv[2]) + string("/deploy.prototxt"),string(argv[2]) + string("/train_val.caffemodel"));


  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);
    std::string path = std::string(argv[3]) + "/" + std::string(entry->d_name);
    std::string output_path = std::string(argv[4])+"/_/"+std::string(entry->d_name);

    Mat full_image = imread(path, CV_LOAD_IMAGE_COLOR), image;
    if(!! full_image.data )                              // Check for invalid input
    {

      Size s = localizer->Dimensions();
      int left, right, up, down;
      Mat iii = resizeContains( full_image, s.width, s.height, left, right, up, down );
      RotatedRect r = localizer->Localize(iii);
      // imwrite(output_path,iii);
      // outfile << "_/"+std::string(entry->d_name) << ",," << r.center.x << "," << r.center.y << "," << r.size.width << "," << r.size.height << "," << r.angle << endl;
      // outfile.flush();


      float factor = 2.2;

      float scale = max( ((float)full_image.cols) / ((float)s.width) , ((float)full_image.rows) / ((float)s.height) );
      r.center.x = (r.center.x - left ) * scale ;
      r.center.y = (r.center.y - up ) * scale ;
      r.size.width = scale * r.size.width ;
      r.size.height = scale * r.size.height / factor ;
      r.size.width = r.size.height;
      // imwrite(output_path,full_image);
      // outfile << "_/"+std::string(entry->d_name) << ",," << r.center.x << "," << r.center.y << "," << r.size.width << "," << r.size.height << "," << r.angle << endl;
      // outfile.flush();

      Mat iiii = extractRotatedRect(full_image, r);
      Mat dst, cdst;
      Canny(iiii, dst, 50, 200, 3);
      cvtColor(dst, cdst, CV_GRAY2BGR);
      vector<Vec4i> lines;
      HoughLinesP(dst, lines, 1, CV_PI/180, 200, 50, 2 );

      int hist [90] = { };
      cout << "Angles " << endl;
      for( size_t i = 0; i < lines.size(); i++ )
      {
        Vec4i l = lines[i];
        //line( cdst, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0,0,255), 3, CV_AA);
        int angle = (  int(atan2( l[3] - l[1] , l[2] - l[0] ) * 180/PI) )  ;
        cout << angle ;
	      if(angle < -45 ) angle = angle + 180 ;
        if(angle > 45) {
		      if(angle <= 135)
			       angle = angle - 90;
		      else
			      angle = angle - 180;
          }

        cout << "[" << angle << "] " ;
	hist[angle + 44] ++ ;
      }


      int rot = distance(hist, max_element(hist, hist + 90)) - 44;
      cout << endl << "Max element " << rot << endl;

      //imwrite(output_path,cdst);
      r.angle = r.angle + rot ;
      imwrite(output_path,full_image);
      outfile << "_/"+std::string(entry->d_name) << ",," << r.center.x << "," << r.center.y << "," << r.size.width << "," << r.size.height << "," << r.angle << endl;
      outfile.flush();


      // Size presise_s = precise_localizer->Dimensions();
      // resize(iiii,iiii,presise_s,0,0,INTER_AREA);
      // RotatedRect r2 = precise_localizer->Localize(iiii);
      // imwrite(output_path,iiii);
      // outfile << "_/"+std::string(entry->d_name) << ",," << r2.center.x << "," << r2.center.y << "," << r2.size.width << "," << r2.size.height << "," << r2.angle << endl;
      // outfile.flush();



      // //
      // // grid search
      // for(int rot = - 40 ; rot <= 40 ; rot+=10 )
      //   for(int delta_x = -100; delta_x <= 100; delta_x += 30 )
      //     for(int delta_y = -100; delta_y <= 100; delta_y += 30 )
      // {
      //
      //   string s_output_path = output_path;
      //   cout << s_output_path.insert(output_path.length()-4, "(" + std::to_string(rot) + ")") << endl;
      //   cout << s_output_path.insert(output_path.length()-4, "(" + std::to_string(delta_x) + ")") << endl;
      //   cout << s_output_path.insert(output_path.length()-4, "(" + std::to_string(delta_y) + ")") << endl;
      //   imwrite(s_output_path,extractRotatedRect(full_image,RotatedRect( r.center + Point2f(delta_x, delta_y ), r.size, r.angle + rot ) ) );
      //
      // }


      // Mat img;
      // cvtColor(full_image, img, CV_RGB2GRAY);
      // HOGDescriptor d;
      // // Size(128,64), //winSize
      // // Size(16,16), //blocksize
      // // Size(8,8), //blockStride,
      // // Size(8,8), //cellSize,
      // // 9, //nbins,
      // // 0, //derivAper,
      // // -1, //winSigma,
      // // 0, //histogramNormType,
      // // 0.2, //L2HysThresh,
      // // 0 //gammal correction,
      // // //nlevels=64
      // //);
      //
      // // void HOGDescriptor::compute(const Mat& img, vector<float>& descriptors,
      // //                             Size winStride, Size padding,
      // //                             const vector<Point>& locations) const
      // vector<float> descriptorsValues;
      // vector<Point> locations;
      // d.compute( img, descriptorsValues, Size(0,0), Size(0,0), locations);
      //
      // cout << "HOG descriptor size is " << d.getDescriptorSize() << endl;
      // cout << "img dimensions: " << img.cols << " width x " << img.rows << "height" << endl;
      // cout << "Found " << descriptorsValues.size() << " descriptor values" << endl;
      // cout << "Nr of locations specified : " << locations.size() << endl;

      // GaussianBlur( full_image, full_image, Size(3,3), 0, 0, BORDER_DEFAULT );
      //
      // int scale = 1;
      // int delta = 0;
      // int ddepth = CV_16S;
      // Mat grad_x, grad_y, abs_grad_x, abs_grad_y, grad;
      // Sobel( full_image, grad_x, ddepth, 1, 0, 3, scale, delta, BORDER_DEFAULT );
      // convertScaleAbs( grad_x, abs_grad_x );
      // Sobel( full_image, grad_y, ddepth, 0, 1, 3, scale, delta, BORDER_DEFAULT );
      // convertScaleAbs( grad_y, abs_grad_y );
      // addWeighted( abs_grad_x, 0.5, abs_grad_y, 0.5, 0, grad );
      // imshow( "window_name", grad );
      //
      // for(int i = 0; i < grad.rows ; i ++)
      //   for(int j = 0; j < grad.cols; j++)
      //     if( abs_grad_x.at<float>(i,j) > 0.001 && abs_grad_x.at<float>(i,j) < 1000000 && abs_grad_y.at<float>(i,j) > 0.001 && abs_grad_y.at<float>(i,j) < 1000000 )
      //       cout << atan2(grad_y.at<float>(i,j),grad_x.at<float>(i,j)) / 3.1415 * 180.0<< endl;

      // Mat orientation = Mat::zeros(360,1,CV_32F);
      // for(int i = 10; i < min(abs_grad_x.rows,abs_grad_y.rows)-10; i++){
      //   for(int j = 10; j < min(abs_grad_x.cols,abs_grad_y.cols) -10; j++){
      //   // Retrieve a single value
      //
      //   float valueX = grad_x.at<float>(i,j);
      //   float valueY = grad_y.at<float>(i,j);
      //   // cout << valueX << endl;
      //   // cout << valueY << endl;
      //   if( grad.at<float>(i,j) > 1000000000.0 ) {
      //     float result = atan2(valueY,valueX) / 3.1415 * 180.0;
      //     // orientation.at<float>((int)result,1) = orientation.at<float>((int)result,1) + 1;
      //     cout << (int) (result) << endl;
      //   }
      //
      //
      //   // if( valueX )
      //   // // Calculate the corresponding single direction, done by applying the arctangens function
      //   // float result = fastAtan2(valueY,valueX);
      //   // // Store in orientation matrix element
      //   // orientation.at<float>(i,j) = result;
      //
      //     }
      //  }


  //waitKey();


      //  for(int i = 0; i < 360; i ++) {
      //    cout << orientation.at<float>(i,1) << endl;
      //  }

      // // Quantize the hue to 30 orientation
      // // int obins = 30;
      // // int histSize[] = {obins};
      // // // orientation varies from 0 to 360
      // // float oranges[] = { 0, 360 };
      // // const float* ranges[] = { oranges };
      // // Mat hist;
      // // // we compute the histogram from the 0-th channel
      // // int channels[] = {0};
      // // calcHist( &orientation, 1, channels, Mat(), // do not use mask
      // //        hist, 1, histSize, ranges,
      // //        true, // the histogram is uniform
      // //        false );
      // //
      // double min, max; int minIdx, maxIdx;
      // minMaxIdx(orientation, &min, &max, &minIdx, &maxIdx);
      //
      // printf("min: %i, max: %i\n", minIdx, maxIdx);



    }
  }

    // scale = output['bbox_pred'][0][0]
    // w = int(scale* 227)
    // print "width : ", w

    // print "x,y:",x,y
    // cv2.rectangle(imx,(x - w /2 , y - w /2), ( x + w/2, y + w /2),(255,0,0),3)
  outfile.close();
  return 0;
}
