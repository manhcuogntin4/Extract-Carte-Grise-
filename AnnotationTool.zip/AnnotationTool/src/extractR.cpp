#include <gflags/gflags.h>
#include <glog/logging.h>
#include <google/protobuf/text_format.h>
#include <leveldb/db.h>
#include <leveldb/write_batch.h>
#include <lmdb.h>
#include <stdint.h>
#include <sys/stat.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"


#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <fstream>

using namespace cv;
using namespace std;

#include <fstream>  // NOLINT(readability/streams)
#include <string>

#include "caffe/proto/caffe.pb.h"
#include "Utils.h"

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

DEFINE_string(backend, "lmdb,directory,tesseract,opencv", "The backend for storing the result");
DEFINE_int32(width, 28, "The width of resized output [default:28]");
DEFINE_double(ratio, 1.0, "The ratio of height/width of the resized output [default:1.0]");
DEFINE_bool(rotated, false, "Take orientation of the rectangle into consideration [Default : false]");
DEFINE_bool(keep_rotation, false, "If true, will not extract the rotated rectangle but a bounding box around the rotated rectangle [Default : false]");
DEFINE_bool(correct, false, "Correct the ratio of the input rectangle [Default : false]");
DEFINE_bool(stretch, false, "Stretch the extracted image to width x (heightxratio) [Default : false]");

uint32_t swap_endian(uint32_t val) {
    val = ((val << 8) & 0xFF00FF00) | ((val >> 8) & 0xFF00FF);
    return (val << 16) | (val >> 16);
}

void convert_dataset(const char* csv_filename, const char* db_path, const string& db_backend, const float ratio, const int cols, bool correct, bool rotated, bool keep_rotation, bool stretch) {
  int rows = ratio * cols;

  // Open files
  std::vector<std::vector<std::string> > input;
  readCSV( csv_filename , input);

  string base_path = getbase(csv_filename);
  cout << "Base path: " << base_path << endl;

  // lmdb
  MDB_env *mdb_env;
  MDB_dbi mdb_dbi;
  MDB_val mdb_key, mdb_data;
  MDB_txn *mdb_txn;
  // leveldb
  leveldb::DB* db;
  leveldb::Options options;
  options.error_if_exists = true;
  options.create_if_missing = true;
  options.write_buffer_size = 268435456;
  leveldb::WriteBatch* batch = NULL;
  //tesseract
  vector<Mat> my_images;
  vector<string> letters;
  vector<Point> borders;

  std::ofstream outfile;

  // Open db
  if (db_backend == "leveldb") {  // leveldb
    LOG(INFO) << "Opening leveldb " << db_path;
    leveldb::Status status = leveldb::DB::Open(
        options, db_path, &db);
    CHECK(status.ok()) << "Failed to open leveldb " << db_path
        << ". Is it already existing?";
    batch = new leveldb::WriteBatch();

  } else if (db_backend == "lmdb") {  // lmdb
    LOG(INFO) << "Opening lmdb " << db_path;
    CHECK_EQ(mkdir(db_path, 0744), 0)
        << "mkdir " << db_path << "failed";
    CHECK_EQ(mdb_env_create(&mdb_env), MDB_SUCCESS) << "mdb_env_create failed";
    CHECK_EQ(mdb_env_set_mapsize(mdb_env, 1099511627776), MDB_SUCCESS)  // 1TB
        << "mdb_env_set_mapsize failed";
    CHECK_EQ(mdb_env_open(mdb_env, db_path, 0, 0664), MDB_SUCCESS)
        << "mdb_env_open failed";
    CHECK_EQ(mdb_txn_begin(mdb_env, NULL, 0, &mdb_txn), MDB_SUCCESS)
        << "mdb_txn_begin failed";
    CHECK_EQ(mdb_open(mdb_txn, NULL, 0, &mdb_dbi), MDB_SUCCESS)
        << "mdb_open failed. Does the lmdb already exist? ";

  } else if(db_backend == "directory") {
    LOG(INFO) << "Creating directory " << db_path;
    CHECK_EQ(mkdir(db_path, 0744), 0)
        << "mkdir " << db_path << " failed";
    outfile.open( std::string( db_path ) + "/annotations.dat", std::ios_base::app);

  } else if(db_backend == "tesseract") {
    LOG(INFO) << "Creating directory " << db_path;
    CHECK_EQ(mkdir(db_path, 0744), 0)
        << "mkdir " << db_path << " failed";

  } else if(db_backend == "opencv") {
    // create directories for positive and negative images
    string dir_paths [5] = { string(db_path), string(db_path) + "/pos", string(db_path) + "/neg", string(db_path) + "/pos/img", string(db_path) + "/neg/img" };
    for(int i = 0 ; i < 5 ; i ++) {
      const char * dir_path = dir_paths[i].c_str();
      LOG(INFO) << "Creating directory " << dir_path;
      CHECK_EQ(mkdir(dir_path, 0744), 0)
          << "mkdir " << db_path << " failed";
    }
    outfile.open( std::string( db_path ) + "/pos/info.dat", std::ios_base::app);

  } else {
    LOG(FATAL) << "Unknown db backend " << db_backend;
  }

  // Storing to db
  char label;
  char* pixels = new char[rows * cols];
  int count = 0;
  const int kMaxKeyLength = 10;
  char key_cstr[kMaxKeyLength];
  string value;

  Datum datum;
  datum.set_channels(1);
  datum.set_height(rows);
  datum.set_width(cols);
  LOG(INFO) << "Rows: " << rows << " Cols: " << cols;


  int item_id = 0;

  for(int cursor = 0; cursor < input.size(); cursor++) {
    Mat image = imread(base_path + input[cursor][0], CV_LOAD_IMAGE_COLOR);
    cout << "Image " << base_path + input[cursor][0] << endl;
        // WorkImage image ( base_path + input[cursor][0] );
    int res_x = stoi(input[cursor][2]) ; //* image.factor;
    int res_y = stoi(input[cursor][3]) ; //* image.factor;
    int res_w = stoi(input[cursor][4]) ; //* image.factor;
    int res_h = stoi(input[cursor][5]) ; //* image.factor;

    //extract Rect
    Rect rr_a( res_x - res_w / 2.0 , res_y - res_h / 2.0 , res_w, res_h );
    if(correct)
      correct_ratio ( rr_a, ratio );
    int center_x = getCenterX(rr_a);
    int center_y = getCenterY(rr_a);

    //extract RotatedRect
    int orient = 0;
    if( rotated ) orient = stoi(input[cursor][6]);
    Size2f s;
    if( correct  )
      s = correct_ratio(res_w, res_h, ratio);
    else
      s = Size2f(res_w, res_h);
    RotatedRect rr_a_rot( Point2f(res_x , res_y ) , s, orient );
    if(rotated) {
      rr_a = rr_a_rot.boundingRect();
      center_x = rr_a_rot.center.x ;
      center_y = rr_a_rot.center.y ;
    }

    if(!! image.data ) { //if(image.ok) {
      Mat gray_image;
      cvtColor(image,gray_image,CV_BGR2GRAY);

      //extract image
      Mat extracted_image;
      if(rotated && !keep_rotation)
        extracted_image = extractRotatedRect( gray_image, rr_a_rot );
      else
        extracted_image = gray_image(rr_a);

      int left, right, up, down;
      Mat last_image;
      if(stretch)
        resize(extracted_image,last_image,Size(cols,rows), 0.0, 0.0,INTER_LINEAR);
      else
        last_image = resizeContains(extracted_image, cols, rows, left, right, up, down );

      //copy
      for(int i = 0 ; i < rows ; i++)
        for( int j = 0; j < cols ; j++ )
          pixels[i * cols + j] = last_image.data[i * cols + j];

      label = char2Class(input[cursor][1][0]);

      datum.set_data(pixels, cols*rows);
      datum.set_label(label);
      snprintf(key_cstr, kMaxKeyLength, "%08d", item_id);
      datum.SerializeToString(&value);
      string keystr(key_cstr);

      // Put in db
      if (db_backend == "leveldb") {

        // leveldb
        batch->Put(keystr, value);


      } else if (db_backend == "lmdb") {

        // lmdb
        mdb_data.mv_size = value.size();
        mdb_data.mv_data = reinterpret_cast<void*>(&value[0]);
        mdb_key.mv_size = keystr.size();
        mdb_key.mv_data = reinterpret_cast<void*>(&keystr[0]);
        CHECK_EQ(mdb_put(mdb_txn, mdb_dbi, &mdb_key, &mdb_data, 0), MDB_SUCCESS)
            << "mdb_put failed";


      } else if(db_backend == "directory") {

        string target_dir =std::string(db_path) + "/" + input[cursor][1];
        if( !input[cursor][1].length() )
          target_dir += "_";
        struct stat st;
        if(stat(target_dir.c_str(),&st) != 0)
          CHECK_EQ(mkdir( target_dir.c_str() , 0744), 0)
            << "mkdir " << target_dir << " failed";

        // directory
        imwrite(target_dir+ "/"+ std::to_string(item_id) + ".jpg" , last_image );
        outfile << target_dir+ "/"+ std::to_string(item_id) + ".jpg" << " " << char2Class(input[cursor][1][0]) << endl;


      } else if(db_backend == "tesseract") {

        //tesseract
        my_images.push_back( last_image  );
        letters.push_back( input[cursor][1] );
        borders.push_back(Point(left,right));


      } else if(db_backend == "opencv") {

        // save a positive
        string output_path =  "img/" + std::to_string(item_id) + ".jpg" ;
        if(!rotated) {
          imwrite( string(db_path) + "/pos/" + output_path , gray_image );
          outfile << output_path << " 1 " << rr_a.tl().x << " " << rr_a.tl().y << " " << rr_a.size().width << " " << rr_a.size().height << endl;
        } else {
          imwrite( string(db_path) + "/pos/" + output_path , extracted_image );
          outfile << output_path << " 1 " << 0 << " " << 0 << " " << extracted_image.cols << " " << extracted_image.rows << endl;
        }
        outfile.flush();
        item_id ++;

      } else {
        LOG(FATAL) << "Unknown db backend " << db_backend;
      }

      extracted_image.release();
      last_image.release();
      gray_image.release();

      if (++count % 1000 == 0) {
        // Commit txn
        if (db_backend == "leveldb") {  // leveldb
          db->Write(leveldb::WriteOptions(), batch);
          delete batch;
          batch = new leveldb::WriteBatch();
        } else if (db_backend == "lmdb") {  // lmdb
          CHECK_EQ(mdb_txn_commit(mdb_txn), MDB_SUCCESS)
              << "mdb_txn_commit failed";
          CHECK_EQ(mdb_txn_begin(mdb_env, NULL, 0, &mdb_txn), MDB_SUCCESS)
              << "mdb_txn_begin failed";
        }
      }
    }
    item_id ++;
  }

  // write the last batch
  if (count % 1000 != 0) {
    if (db_backend == "leveldb") {  // leveldb
      db->Write(leveldb::WriteOptions(), batch);
      delete batch;
      delete db;
    } else if (db_backend == "lmdb") {  // lmdb
      CHECK_EQ(mdb_txn_commit(mdb_txn), MDB_SUCCESS) << "mdb_txn_commit failed";
      mdb_close(mdb_env, mdb_dbi);
      mdb_env_close(mdb_env);
    }
    LOG(ERROR) << "Processed " << count << " files.";
  }

  // close the files
  if(db_backend == "tesseract") {
    int dim = 28;
    int gap_size = 20;
    int nb_cols = 30;

    int nb_rows = std::ceil( ((double) my_images.size()) / nb_cols);
    Mat to_show =  createOne(my_images, nb_cols, nb_rows, gap_size, dim);
    imwrite(std::string(db_path) + "/" + "lpfra.std.exp0" + ".tif" , to_show );

    std::ofstream outfile;
    outfile.open( std::string(db_path) + "/" + "lpfra.std.exp0" + ".box", std::ios_base::app);
    int step = gap_size + dim;
    for(int j = 0 ; j < nb_rows ; j ++  )
      for(int i = 0 ; i < nb_cols ; i++ ){
        int ind = j * nb_cols + i;
        if( ind < letters.size() )
          outfile << letters[ind] << " " << i * step + gap_size + borders[i].x << " " << (nb_rows - j) * step + gap_size - dim << " " << (i+1) * step  - borders[i].y << " " << (nb_rows - j) * step + gap_size << " " << 0 << endl;

    }
    outfile.close();
  } else if(db_backend == "opencv" || db_backend == "directory"){
    outfile.close();
  }

  delete pixels;
}

// MAIN FUNCTION
int main(int argc, char** argv) {
#ifndef GFLAGS_GFLAGS_H_
  namespace gflags = google;
#endif

  gflags::SetUsageMessage("This script extract image dataset to\n"
        "a directory format used for visualisation,\n"
        "the Tesseract format used by Tesseract to load data,\n"
        "a OpenCV format used by OpenCV traincascade to load data,\n"
        "the lmdb/leveldb format used by Caffe to load data.\n"
        "Usage:\n"
        "    extract [FLAGS] input_csv_file db_path"
        "\n");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  const string& db_backend = FLAGS_backend;
  const double& ratio = FLAGS_ratio;
  const int& width = FLAGS_width;
  const bool& rotated = FLAGS_rotated;
  const bool& keep_rotation = FLAGS_keep_rotation;
  const bool& correct = FLAGS_correct;
  const bool& stretch = FLAGS_stretch;

  if (argc != 3) {
    gflags::ShowUsageWithFlagsRestrict(argv[0],
        "examples/mnist/convert_mnist_data");
  } else {
    google::InitGoogleLogging(argv[0]);
    convert_dataset(argv[1], argv[2], db_backend, ratio, width, correct, rotated, keep_rotation, stretch);
  }
  return 0;
}
