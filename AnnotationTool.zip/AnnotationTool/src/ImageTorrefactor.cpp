#include "ImageTorrefactor.h"
#include <sstream>
#include <string>

ImageTorrefactor::ImageTorrefactor(const string& model_file, const string& trained_file) {

  // const string& mean_file = "";
  // const string& label_file ="";

#ifdef CPU_ONLY
  Caffe::set_mode(Caffe::CPU);
#else
  Caffe::set_mode(Caffe::GPU);
#endif

  /* Load the network. */
  net_.reset(new Net<float>(model_file, TEST));
  net_->CopyTrainedLayersFrom(trained_file);

  CHECK_EQ(net_->num_inputs(), 1) << "Network should have exactly one input.";
  CHECK_EQ(net_->num_outputs(), 1) << "Network should have exactly one output.";

  Blob<float>* input_layer = net_->input_blobs()[0];
  num_channels_ = input_layer->channels();
  CHECK(num_channels_ == 3 || num_channels_ == 1)
    << "Input layer should have 1 or 3 channels.";
  input_geometry_ = cv::Size(input_layer->width(), input_layer->height());

  /* Load the binaryproto mean file. */
  //SetMean(mean_file);

  /* Load labels. */
  // std::ifstream labels(label_file.c_str());
  // CHECK(labels) << "Unable to open labels file " << label_file;
  // string line;
  // while (std::getline(labels, line))
  //   labels_.push_back(string(line));

  Blob<float>* output_layer = net_->output_blobs()[0];
  // CHECK_EQ(sizeof(legal), output_layer->channels())
  //   << "Number of labels is different from the output layer dimension.";


}


cv::Size ImageTorrefactor::Dimensions() {
  return input_geometry_;
};

int ImageTorrefactor::output_width (){

  return net_->output_blobs()[0]->shape(3);
};
int ImageTorrefactor::output_height () {

  return net_->output_blobs()[0]->shape(2);
};

void ImageTorrefactor::reshape(int width, int height) {

  input_geometry_.height = height;
  input_geometry_.width = width;

  Blob<float>* input_layer = net_->input_blobs()[0];

  input_layer->Reshape(1, num_channels_,
                       input_geometry_.height, input_geometry_.width);
  /* Forward dimension change to all layers. */
  net_->Reshape();

}



/* Return the top N predictions. */
std::vector<Prediction> ImageTorrefactor::Classify(const cv::Mat& img, int N, const char * dict) {
  std::vector<float> output = Predict(img);

  std::vector<int> maxN = Argmax(output, N);
  std::vector<Prediction> predictions;
  for (int i = 0; i < N; ++i) {
    int idx = maxN[i];

    stringstream ss;
    string s;

    ss << dict[idx];
    ss >> s;
    predictions.push_back(std::make_pair(s, output[idx]));
  }
  return predictions;
}

std::vector<Prediction> ImageTorrefactor::Classify(Mat gray_image, int x, int y, int w, int h, int N ) {
  //cv::Mat sub = image.gray_image(r - Point ( 2, 2 ) + Size(4, 4) );
  // cv::Mat sub = image.gray_image(r);
  int left, right, up, down;
  cv::Mat sub;
  cout << "check dim " << input_geometry_.width << "," << input_geometry_.height << " vs " << w << "," << h << endl;
  if( w != input_geometry_.width && h != input_geometry_.height )
    sub = resizeContains( gray_image( Rect(Point(x,y),Size(w,h))  )   , input_geometry_.width, input_geometry_.height ,left,right,up,down );
  else
    sub = gray_image(Rect(Point(x,y),Size(w,h)));

  return Classify( sub, N );

}

/* Load the mean file in binaryproto format. */
void ImageTorrefactor::SetMean(const string& mean_file) {
  BlobProto blob_proto;
  ReadProtoFromBinaryFileOrDie(mean_file.c_str(), &blob_proto);

  /* Convert from BlobProto to Blob<float> */
  Blob<float> mean_blob;
  mean_blob.FromProto(blob_proto);
  CHECK_EQ(mean_blob.channels(), num_channels_)
    << "Number of channels of mean file doesn't match input layer.";

  /* The format of the mean file is planar 32-bit float BGR or grayscale. */
  std::vector<cv::Mat> channels;
  float* data = mean_blob.mutable_cpu_data();
  for (int i = 0; i < num_channels_; ++i) {
    /* Extract an individual channel. */
    cv::Mat channel(mean_blob.height(), mean_blob.width(), CV_32FC1, data);
    channels.push_back(channel);
    data += mean_blob.height() * mean_blob.width();
  }

  /* Merge the separate channels into a single image. */
  cv::Mat mean;
  cv::merge(channels, mean);

  /* Compute the global mean pixel value and create a mean image
   * filled with this value. */
  cv::Scalar channel_mean = cv::mean(mean);
  mean_ = cv::Mat(input_geometry_, mean.type(), channel_mean);
}

std::vector<float> ImageTorrefactor::Predict(const cv::Mat& img) {
    // cout << "predict" << endl;
  Blob<float>* input_layer = net_->input_blobs()[0];

  input_layer->Reshape(1, num_channels_,
                       input_geometry_.height, input_geometry_.width);
  /* Forward dimension change to all layers. */
  net_->Reshape();

  std::vector<cv::Mat> input_channels;
  WrapInputLayer(&input_channels);

  Preprocess(img, &input_channels);

  // net_->ForwardPrefilled();
  net_->Forward();
//  net_->Forward();
  // net_->ForwardFrom(1);


  // cout << "Network name : " << net_->name() << endl;
  // vector<boost::shared_ptr<Blob<float> > > net_blobs = net_->blobs() ;
  // vector<string> net_blob_names  = net_->blob_names();
  // for(int i = 0; i < net_blobs.size(); i ++){
  //   if(net_blob_names[i]  == "theta") {
  //     cout << net_blob_names[i] << endl;
  //
  //     vector<int> s = net_blobs[i]->shape();
  //     cout << "Shape " ;
  //     for( int j = 0; j < s.size(); j++)
  //       cout << s[j] << "x";
  //       cout << endl;
  //     for( int j = 0; j < 6; j ++ ) {
  //       float x = net_blobs[i]->data_at(0, j, 0, 0);
  //       cout << "val " << std::to_string(x) << endl;
  //
  //     }
  //   }
  // }

  /* Copy the output layer to a std::vector */
  Blob<float>* output_layer = net_->output_blobs()[0];
  //cout << "Shape :" << output_layer->shape_string() << endl;
  //cout << "Channels :" << output_layer->channels() << endl;
  const float* begin = output_layer->cpu_data();
  const float* end = begin + output_layer->count();

  return std::vector<float>(begin, end);
}

/* Wrap the input layer of the network in separate cv::Mat objects
 * (one per channel). This way we save one memcpy operation and we
 * don't need to rely on cudaMemcpy2D. The last preprocessing
 * operation will write the separate channels directly to the input
 * layer. */
void ImageTorrefactor::WrapInputLayer(std::vector<cv::Mat>* input_channels) {
  Blob<float>* input_layer = net_->input_blobs()[0];

  int width = input_layer->width();
  int height = input_layer->height();
  float* input_data = input_layer->mutable_cpu_data();
  for (int i = 0; i < input_layer->channels(); ++i) {
    cv::Mat channel(height, width, CV_32FC1, input_data);
    input_channels->push_back(channel);
    input_data += width * height;
  }
}

void ImageTorrefactor::Preprocess(const cv::Mat& img,
                            std::vector<cv::Mat>* input_channels) {
  /* Convert the input image to the input image format of the network. */
  cv::Mat sample;
  if (img.channels() == 3 && num_channels_ == 1)
    cv::cvtColor(img, sample, CV_BGR2GRAY);
  else if (img.channels() == 4 && num_channels_ == 1)
    cv::cvtColor(img, sample, CV_BGRA2GRAY);
  else if (img.channels() == 4 && num_channels_ == 3)
    cv::cvtColor(img, sample, CV_BGRA2BGR);
  else if (img.channels() == 1 && num_channels_ == 3)
    cv::cvtColor(img, sample, CV_GRAY2BGR);
  else
    sample = img;

  cv::Mat sample_resized;
  if (sample.size() != input_geometry_)
    cv::resize(sample, sample_resized, input_geometry_);
  else
    sample_resized = sample;

  cv::Mat sample_float;
  if (num_channels_ == 3)
    sample_resized.convertTo(sample_float, CV_32FC3);
  else
    sample_resized.convertTo(sample_float, CV_32FC1);

  cv::Mat sample_normalized;
//  cv::subtract(sample_float, mean_, sample_normalized);

  /* This operation will write the separate BGR planes directly to the
   * input layer of the network because it is wrapped by the cv::Mat
   * objects in input_channels. */
//  cv::split(sample_normalized, *input_channels);

  cv::split(sample_float, *input_channels);

  CHECK(reinterpret_cast<float*>(input_channels->at(0).data)
        == net_->input_blobs()[0]->cpu_data())
    << "Input channels are not wrapping the input layer of the network.";
}

std::string ImageTorrefactor::readRects ( Mat gray_image , vector<cv::Rect> & orderedRects, int threshold ) {
  int ln = orderedRects.size();
  std::vector<Prediction>* predictions = new std::vector<Prediction>[ln];
  for( int i = 0 ; i < ln ; i ++) {
    predictions[i] = Classify(gray_image, orderedRects[i].x, orderedRects[i].y, orderedRects[i].width, orderedRects[i].height);
    cout << predictions[i][0].first[0] << " : " << predictions[i][0].second << endl;
  }

  // // take the 7 max indexes
  // int* is_max = new int[ln];
  // for(int i = 0 ; i < ln; i ++ ) is_max[i] = 0;
  // float last_max = 100000000000 ;
  // for ( int j = 0 ; j < 7; j ++ ) {
  //   float max = 0;
  //   int index_max;
  //   for(int i = 0 ; i < ln; i ++ ) {
  //     if( (predictions[i][0].second > max ) && (predictions[i][0].second < last_max) && (predictions[i][0].second > 2500)) {
  //       max = predictions[i][0].second;
  //       index_max = i;
  //     }
  //   }
  //   last_max = max;
  //   is_max[index_max] = 1;
  // }

  string text = "";
  for(int i = 0 ; i < ln; i ++ ) {
    // if( is_max[i] )
    if(predictions[i][0].second > threshold)
      text += predictions[i][0].first[0];
  }

  // if((predictions.size() > 0))
  //   text += predictions[0].first[0];
  //
  cout << "OCR output : " << text << endl;
  return text ;
}

RotatedRect ImageTorrefactor::Localize(Mat full_image) {
  Mat image;
  Blob<float>* input_layer = net_->input_blobs()[0];
  cout << "Localizing : " ;
  cout << "  resizing from [" << full_image.rows << "x" << full_image.cols << "] to " << input_layer->width() << "x" << input_layer->height() << endl;

  resize(full_image,image,cv::Size(input_layer->width(), input_layer->height()),0,0,INTER_AREA);
  full_image.release();


  std::vector<float> output = Predict(image);
  image.release();
  // cout << output[0] << "," << output[1] << "," << output[2] << "," << output[3] << endl;
  // cout << output.size() << endl; break;
  float r = 0, x,y,w;
  if(( output.size() == 3) || (output.size() == 4)) {
    if(output.size() == 4)
      r = (output[3] * 180 + 180)  ;

    // std::vector<int> maxN = Argmax(output, 1);
    // cout << "Result :" << maxN[0] << endl;
    float scale = output[0] ;
    w = scale * 227 ;
    x = (output[1]/2.0 + 0.5 ) * 227 ;
    y = (output[2]/2.0 + 0.5 ) * 227 ;
  } else if(output.size() == 6) {
    float scale = sqrt(output[0] * output[4] - output[1] * output[3]);
    w = scale * 227 ;
    r = atan2( output[3] , output[0] ) * 180 / 3.1415;
    x = (output[2]/2.0 + 0.5 ) * 227 ;
    y = (output[5]/2.0 + 0.5 ) * 227 ;
  }

  return RotatedRect(Point2f(x,y),Size(w,w),r);
}
