#include "ImageTesseractor.h"

ImageTesseractor::ImageTesseractor (char * lang)
{
  api = new tesseract::TessBaseAPI();
  // Initialize tesseract-ocr with English, without specifying tessdata path
  if (api->Init(NULL, lang)) {
      fprintf(stderr, "Could not initialize tesseract.\n");
      exit(1);
  }
}


char ImageTesseractor::readRectFirst( WorkImage image, Rect r ) {
  char *outText;
  RNG rng(12355);
  Scalar color2 = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );

  rectangle( image.image, r.tl(), r.br(), color2, 2, 8, 0 );
  Mat sub = image.gray_image(r - Point ( 2, 2 ) + Size(4, 4) );
  api->SetImage((uchar*)sub.data, sub.size().width, sub.size().height, sub.channels(), sub.step1());
  api->SetVariable("tessedit_char_whitelist", "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
  outText = api->GetUTF8Text();

  int len = strlen(outText);
  string result;
  for (int i=0; i<len; i++){
      if (isLegal(*(outText+i))){
        result += (*(outText+i));
      }
  }

  return result[0];
};

char ImageTesseractor::readRect( WorkImage image, Rect r ) {
  RNG rng(12355);
  Scalar color2 = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
  rectangle( image.image, r.tl(), r.br(), color2, 2, 8, 0 );
  Mat sub = image.gray_image(r - Point ( 2, 2 ) + Size(4, 4) );
  api->SetImage((uchar*)sub.data, sub.size().width, sub.size().height, sub.channels(), sub.step1());

  api->SetVariable("tessedit_char_whitelist", "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
  api->SetVariable("save_blob_choices", "T");
  api->Recognize(NULL);

  tesseract::ResultIterator* ri = api->GetIterator();
  tesseract::PageIteratorLevel level = tesseract::RIL_SYMBOL;
  float conf_max = 0;
  char symbol_max;

  if(ri != 0) {
      do {
          const char* symbol = ri->GetUTF8Text(level);
          float conf = ri->Confidence(level);
          if(symbol != 0) {
              printf("symbol %s, conf: %f", symbol, conf);
              if( conf > conf_max) {
                conf_max = conf;
                symbol_max = symbol[0];
              }

              bool indent = false;
              tesseract::ChoiceIterator ci(*ri);
              do {
                  if (indent) printf("\t\t ");
                  printf("\t- ");
                  const char* choice = ci.GetUTF8Text();
                  printf("%s conf: %f\n", choice, ci.Confidence());
                  indent = true;
              } while(ci.Next());
          }
          printf("---------------------------------------------\n");
          delete[] symbol;
      } while((ri->Next(level)));
  }

  return symbol_max;
}


std::string ImageTesseractor::readRects ( WorkImage image, vector<cv::Rect> & orderedRects ) {
  string text = "";
  for( int i = 0 ; i < orderedRects.size() ; i ++)
    text += readRect( image , orderedRects[i] );
  cout << "OCR output : " << text << endl;
  return text;
}
