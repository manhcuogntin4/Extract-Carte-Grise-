#include "ImageTorrefactor.h"
#include <glog/logging.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{

  if( argc != 4)
  {
   cout <<" Usage: ./recognizePlateWithCaffe cascade.xml input_dir output_dir" << endl;
   return -1;
  }

  google::InitGoogleLogging(argv[0]);

  CHECK_EQ(mkdir(argv[3], 0744), 0)
      << "mkdir " << argv[3] << "failed";

  CascadeClassifier* plate_cc = new CascadeClassifier(string(argv[1])) ;
  ImageTorrefactor * plate_letters_classifier = new ImageTorrefactor(  string("models/deploy.prototxt"),string("models/lenet_iter_2000.caffemodel"));

  std::ofstream outfile;
  outfile.open( (std::string(argv[3]) + "/results.csv").c_str(), std::ios_base::app);

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[2]);
  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);
    std::string path = std::string(argv[2]) + "/" + std::string(entry->d_name);
    string output_path = string(argv[3]) + "/" + std::string(entry->d_name);
    WorkImage image ( path );
    if(image.ok) {
      Mat display_image = image.image.clone();
      vector<cv::Rect> plateZone;
      vector<vector<cv::Point> > all_contours;
      detectRectsAndContours(plate_cc,image, plateZone, all_contours);

      vector<string> textV;

      for(int j = 0 ; j < plateZone.size(); j++ ) {
        vector<cv::Rect> orderedRects;  vector<vector<cv::Point> > orderedContours;
        extractRect(image,plateZone[j], all_contours,orderedContours,orderedRects);
        std::string text = plate_letters_classifier->readRects( image.gray_image , orderedRects, 2000 );
        textV.push_back(text);
        displayRects(display_image, orderedRects);
      }

      displayRects(display_image,plateZone);

      int textmax = 0;
      int argtextmax = 0;
      for (int i = 0 ; i < textV.size() ; i ++ ) {
        if(textV[i].length() > textmax)
          {
            textmax = textV[i].length();
            argtextmax = i;
           }
      }

      if(textV.size() > 0) {
        displayText(display_image,textV[argtextmax]);
        outfile << path << "," << textV[argtextmax] << endl;
      } else outfile << path << "," << endl;
      outfile.flush();

      imwrite( output_path , display_image );
      imwrite( output_path.replace(output_path.end()-4,output_path.end(),"-2.jpg") , image.threshold_image );
      display_image.release();

    }
  }
  outfile.close();
  return 0;
}
