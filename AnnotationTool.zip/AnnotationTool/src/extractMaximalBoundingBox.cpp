#include <gflags/gflags.h>
#include <glog/logging.h>
#include <google/protobuf/text_format.h>
#include <leveldb/db.h>
#include <leveldb/write_batch.h>
#include <lmdb.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>
#include <limits>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"

#define PI 3.14159265

#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <fstream>

using namespace cv;
using namespace std;

#include <fstream>  // NOLINT(readability/streams)
#include <string>

#include "caffe/proto/caffe.pb.h"
#include "Utils.h"

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

DEFINE_double(factor, 1.3, "The ratio  [default:1.3]");

uint32_t swap_endian(uint32_t val) {
    val = ((val << 8) & 0xFF00FF00) | ((val >> 8) & 0xFF00FF);
    return (val << 16) | (val >> 16);
}

Mat extractRotatedRect(RotatedRect rect, Mat src ) {
  // matrices we'll use
  Mat M, rotated, cropped;
  // get angle and size from the bounding box
  float angle = rect.angle;
  Size rect_size = rect.size;
  // thanks to http://felix.abecassis.me/2011/10/opencv-rotation-deskewing/
  if (rect.angle < -45.) {
      angle += 90.0;
      swap(rect_size.width, rect_size.height);
  }
  // get the rotation matrix
  M = getRotationMatrix2D(rect.center, angle, 1.0);
  // perform the affine transformation
  warpAffine(src, rotated, M, src.size(), INTER_CUBIC);
  // crop the resulting image
  getRectSubPix(rotated, rect_size, rect.center, cropped);
  return cropped;
}


void convert_dataset(const char* csv_letter_filename, const char* csv_plate_filename, float factor) {

  std::ofstream outfile;
  outfile.open( std::string( csv_plate_filename ) , std::ios_base::app);

  //statistics
  double average_width = 0;
  double average_height = 0;
  int average_count = 0;
  int max_width = 0;
  int min_width = 1000000000;
  int max_height = 0;
  int min_height = 1000000000;
  int min_orientation = 90;
  int max_orientation = -90;


  std::vector<std::vector<std::string> > input;
  readCSV( csv_letter_filename , input);

  vector<string> dejavu;
  for(int cursor = 0; cursor < input.size(); cursor++) {

      if(find(dejavu.begin(), dejavu.end(), input[cursor][0]) == dejavu.end() ) {
        cout << "Item : " << input[cursor][0] << endl;
        dejavu.push_back(input[cursor][0]);

        // extraction of letters
        vector<Rect> outputRects ;
        findRectangle( input[cursor][0], std::string( csv_letter_filename ) , outputRects );

        // Si plaque détectée
        if(outputRects.size() > 0) {

          // calcul des coordonnées de la plaque
          int x_min = INT_MAX , x_max = 0, y_min = INT_MAX, y_max = 0;
          int height = 0;
          int counts = 0; float slope = 0;
          for(int i = 0; i < outputRects.size(); i++ ) {
            height += outputRects[i].br().y - outputRects[i].tl().y;

            if( outputRects[i].tl().x < x_min )
              x_min = outputRects[i].tl().x;
            if( outputRects[i].br().x > x_max )
              x_max = outputRects[i].br().x;
            if( outputRects[i].tl().y < y_min )
              y_min = outputRects[i].tl().y;
            if( outputRects[i].br().y > y_max )
              y_max = outputRects[i].br().y;

            int x1 = getCenterX(outputRects[i]);
            int y1 = getCenterY(outputRects[i]);
            if(i + 1 < outputRects.size() )
              for(int j = i + 1; j < outputRects.size(); j++ ) {
                int x2 = getCenterX(outputRects[j]);
                int y2 = getCenterY(outputRects[j]);
                slope += ((float)(y2 - y1)) / ((float)(x2 - x1));
                counts ++;
              }
          }

          // La plaque en Rect
          int width = x_max - x_min;
          Rect rr( x_min, y_min, width, y_max - y_min);
          float fact_x = factor ;
          float fact_y = factor;
          // float fact_x = 1.3;
          // float fact_y = 1.25;
          Rect rr_a( x_min - ( fact_x - 1.0 ) * width / 2.0 , y_min - ( fact_y - 1.0 ) * (y_max - y_min) / 2.0 , width * fact_x, (y_max - y_min) * fact_y );

          // La plaque en RotatedRect
          int center_x = getCenterX(rr);
          int center_y = getCenterY(rr);
          height = ceil(((float)height) / ((float)outputRects.size()));
          slope = slope / counts;
          double orientation = atan(slope) * 180 / PI;
          RotatedRect rd( Point(center_x, center_y), Size(width, height), orientation);
          // RotatedRect rd_a( Point(center_x, center_y), Size(width * 1.1, height *1.2), orientation);
          // cout << "Rectangle : " << rr << endl;

          // Statistics
          average_width += width;
          average_height += height;
          average_count ++;
          if(width > max_width) max_width = width;
          if(width < min_width) min_width = width;
          if(height < min_height) min_height = height;
          if(height > max_height) max_height = height;
          if(orientation > max_orientation) max_orientation = orientation;
          if(orientation < min_orientation) min_orientation = orientation;

          outfile << input[cursor][0] << ",0," << rr_a.tl().x + rr_a.size().width/2.0 << "," << rr_a.tl().y + rr_a.size().height/2.0 << "," << rr_a.size().width << "," << rr_a.size().height << "," << orientation << endl;

        }

      }
    }

  outfile.close();

  //statistics
  average_width /= ((double)average_count);
  average_height /= ((double)average_count);
  cout << "Average rectangle width : " << average_width << endl;
  cout << "Average rectangle height : " << average_height << endl;
  cout << "Max width : " << max_width << endl;
  cout << "Min width : " << min_width << endl;
  cout << "Max height : " << max_height << endl;
  cout << "Min height : " << min_height << endl;
  cout << "Max orientation : " << max_orientation << endl;
  cout << "Min orientation : " << min_orientation << endl;

}

// MAIN FUNCTION
int main(int argc, char** argv) {
#ifndef GFLAGS_GFLAGS_H_
  namespace gflags = google;
#endif

  gflags::SetUsageMessage("This script extract the bounding box containing \n"
        "all rectangles of the images.\n"
        "Usage:\n"
        "    extractRectanglesBoundingBox input_rectangles.csv output_boundingbox.csv"
        "\n");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  const double& factor = FLAGS_factor;

  if (argc != 3) {
    gflags::ShowUsageWithFlagsRestrict(argv[0],
        "examples/mnist/convert_mnist_data");
  } else {
    google::InitGoogleLogging(argv[0]);
    convert_dataset(argv[1], argv[2], factor);
  }
  return 0;
}
