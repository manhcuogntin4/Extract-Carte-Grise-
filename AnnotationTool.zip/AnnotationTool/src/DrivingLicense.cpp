#include "DrivingLicense.h"

const float DrivingLicense::rx = 0.50f;
const int DrivingLicense::input_width = 400, DrivingLicense::input_height = 340;
const int DrivingLicense::letter_w = 18, DrivingLicense::letter_h = 25;

void DrivingLicense::resize_original(float max_dim) {
   // simulation de resize d'input image
   float fff = max_dim / ((float) std::max( full_image.rows, full_image.cols )) ;
   resize(full_image, full_image, Size(),fff,fff,INTER_AREA);
   compute();
 }

int DrivingLicense::get_position_w( float y ) {
  return ((float)input_width) / 2.0 + 2.0 * 2.0 * ( y - ((float)output_width) / 2.0);
}

int DrivingLicense::get_position_h( float y ) {
  return ((float)input_height) / 2.0 + 2.0 * 2.0 * ( y - ((float)output_height) / 2.0);
}

// compute orientation value between -180 and 180
void DrivingLicense::orientate(ImageTorrefactor * localizer){

  Size s = localizer->Dimensions();
  int left, right, up, down;
  Mat iii = resizeContains( full_image, s.width, s.height, left, right, up, down );
  RotatedRect r = localizer->Localize(iii);

  cout << "  Localizer orientation : " << r.angle << endl;// [-180,180]

  int rot = compute_orientation(image); // [0,180[
  if( rot >= 90 ) rot = rot - 90;// [0,90[
  cout << "  Line orientations : " << rot << endl;


//[-180, 180[
  vector<int> vals ;
  vals.push_back(rot-180);
  vals.push_back(rot-90);
  vals.push_back(rot);
  vals.push_back(rot+90);
  int min_dist = 10000000;
  int argmin_index = 0;
  for ( int i = 0 ; i < 4; i ++) {
    int dist = min(abs(vals[i] - r.angle ), 360 - abs(vals[i] - r.angle));
    if(  dist < min_dist ) {
      min_dist = dist;
      argmin_index = i;
    }
  }

  cout << "  Rotation final : " << vals[argmin_index] << endl;

  int len = std::max(full_image.rows, full_image.cols);
  cv::Point2f pt(len/2., len/2.);
  cv::Mat rotation_matrix = cv::getRotationMatrix2D(pt, vals[argmin_index] , 1.0);
  cv::warpAffine(full_image, full_image, rotation_matrix, Size(len,len), INTER_LINEAR, BORDER_CONSTANT, white);
  compute();

}

void DrivingLicense::findZones( CascadeClassifier* cc ) {
  cout << "    Nb detected zones : " ;
  cc->detectMultiScale(gray_image,zones,1.1,1);
  cout << zones.size() << endl ;
}

void DrivingLicense::compute_lines(ImageTorrefactor * positioning_classifier, Rect zone) {
  cout << "    Compute lines" << endl;
  positioning_classifier->reshape(input_width,input_height);
  output_width = positioning_classifier->output_width();
  output_height = positioning_classifier->output_height();

  int full_w = zone.size().width / factor, full_h =  zone.size().height / factor ;
  int full_tl_x = zone.tl().x / factor ;
  full_tl_x = std::min( full_tl_x + (int)(full_w * 0.1) , full_image.cols - full_w );
  int full_tl_y = std::min( (int)(zone.tl().y / factor), full_image.rows - full_h ) ;

  Mat zone_image = full_image( Rect( Point(full_tl_x, full_tl_y), Size(full_w, full_h) ));

  Mat resized_zone;
  resize(zone_image,resized_zone,Size(input_width,input_height));
  cvtColor(resized_zone,gray_resized_zone,CV_BGR2GRAY);

  // Display only//
  cvtColor(gray_resized_zone, c_gray_resized_zone, CV_GRAY2RGB);

  // convolution, extraction de l'image correspondant au label positif
  // et récupération des 250 points positifs
  cout << "      feature map" << endl;
  positioning_classifier->reshape(input_width,input_height);
  std::vector<float> output = positioning_classifier->Predict(gray_resized_zone);
  // cout << output.size() << " - " << output_width * output_height << endl;
  std::vector<float> output_positive ;

  for(int i = 0; i < output_width * output_height; i ++ ) {
      output_positive.push_back (output[i]) ;
  }
  std::vector<int> maxN = Argmax(output_positive, 250);

  // calcul des positions correspondantes (et suppression des points sur les bords)
  cout << "      line positions" << endl;
  float t = rx * output_width;
  //cout << "Treshold " << t;
  std::vector<Point> letter_points;
  for(int i = 0; i < maxN.size() ; i ++ ) {
    int position = maxN[i];
    if( position % output_width > (int) t ){
      //cout << position % output_width << position / output_width << endl;
      letter_points.push_back(Point( get_position_w(position % output_width ), get_position_h(position / output_width) ));
    }
  }
  //cout << "Letter points size " << letter_points.size() << endl;

  // calcul des 7 lignes
  if( letter_points.size() > 7 ) {
    Mat mtx(letter_points.size(), 1, CV_32F), bestLabels, centers;
    for(int i = 0; i < letter_points.size(); i ++)
      mtx.at<float>(i,0) = letter_points[i].y;
    cv::kmeans(mtx,7,bestLabels, cv::TermCriteria(CV_TERMCRIT_ITER, 10, 1.0),3, cv::KMEANS_PP_CENTERS, centers);
    vector<float> line_y ;
    for(int i = 0 ; i < centers.rows ; i ++){
      //cout << "Center :" << centers.at<float>(i,0) << endl;
      line_y.push_back( centers.at<float>(i,0) );
    }

    // création des lignes de points
    vector<Point> lines [ 7 ] = {};
    for (int i = 0; i < bestLabels.rows; i++)
      lines[bestLabels.at<int>(i,0)].push_back( letter_points[i] );

    // order lines
    vector<int> order;
    float last_min = -10.0;
    for( int i = 0 ; i < centers.rows ; i ++) {
      // le minimum courant et son index
      float current_min = 100000000000.0;
      int current_argmin;
      // on cherche un minimum supérieur au dernier min
      for( int j = 0; j < centers.rows ; j ++) {
        float y_j = centers.at<float>(j,0);
        if( y_j < current_min && y_j > last_min ) {
          current_argmin = j;
          current_min = y_j;
        }
      }
      // on met à jour le dernier min
      last_min = current_min;

      order.push_back(current_argmin);
    }

    vector< vector<Point> > ordered_lines;
    ordered_lines_y.clear();
    float last_y = - 10.0;
    for(int i = 0; i < order.size(); i ++) {
      int line_index = order[i];

      if(  centers.at<float>(line_index,0) > last_y +5.0 ) {
        //création d'une nouvelle ligne
        ordered_lines.push_back(lines[line_index]);
        last_y = centers.at<float>(line_index,0);
        ordered_lines_y.push_back( centers.at<float>(line_index,0) );

      } else {
        // on fait la moyenne pondérée des lignes comme y celle des deux lignes qui a le plus de points
        //ajout à la ligne précédente
        if( lines[line_index].size() > ordered_lines[ordered_lines.size()-1].size() )
          ordered_lines_y[ordered_lines.size()-1] = centers.at<float>(line_index,0);
        for(int j = 0; j < lines[line_index].size(); j ++)
          ordered_lines[ordered_lines.size()-1].push_back(lines[line_index][j]);
      }
    }

    ordered_line_x_min.clear();
    ordered_line_x_max.clear();
    for(int i = 0; i < ordered_lines.size(); i ++ ) {
      int c_min = gray_resized_zone.cols;
      int c_max = 0;
      for(int j = 0; j < ordered_lines[i].size(); j++) {
        if( (ordered_lines[i][j].y > ordered_lines_y[i] - 5) && (ordered_lines[i][j].y < ordered_lines_y[i] + 5) ) {
          int x = ordered_lines[i][j].x ;
          if( x > c_max)
            c_max = x;
          if( x < c_min)
            c_min = x;
        }
      }
      ordered_line_x_min.push_back(c_min);
      ordered_line_x_max.push_back(c_max);
    }
// //       // for(int i = 0; i < letter_points.size() ; i ++ )
// //       //   displayCross(c_gray_resized_zone,letter_points[i]);
// //       RNG rng(12355);
// //       // Scalar color1 = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
// //       // for(int i = 0 ; i < centers.rows ; i ++)
// //       //   line(c_gray_resized_zone, Point2f(0.0,line_y[i]), Point2f(100,line_y[i]), color1, 1, 8, 0 );

    mtx.release();
    bestLabels.release();
    centers.release();
  }
  zone_image.release();
  resized_zone.release();

}

// void DrivingLicense::displaylines() {
    // Scalar color2 = Scalar( rng.uniform(0, 155), rng.uniform(0,155), rng.uniform(0,155) );
    // for(int i = 0 ; i < ordered_lines_y.size() ; i ++)
    //  line(c_gray_resized_zone, Point2f(0.0,ordered_lines_y[i]), Point2f(100,ordered_lines_y[i]), color2, 1, 8, 0 );
    // for(int i = 0 ; i < ordered_lines_y.size() ; i ++)
    //   for(int j = 0; j < 10 ; j ++ )
    //     displayCross(c_gray_resized_zone, Point2f(ordered_line_x_min[i]+ j * 11,ordered_lines_y[i]));
      // line(c_gray_resized_zone, Point2f(ordered_line_x_min[i],ordered_lines_y[i]), Point2f(ordered_line_x_max[i],ordered_lines_y[i]), color2, 1, 8, 0 );
// }

void DrivingLicense::compute_letter_positions(ImageTorrefactor * positioning_classifier) {
  // calcul le long des lignes
  cout << "    Letter position" << endl;
  positioning_classifier->reshape(letter_w, letter_h);

  ordered_lines_RotatedRects.clear();
  for(int i = 0 ; i < ordered_lines_y.size() ; i ++) {
    if( (ordered_lines_y[i] > letter_h/2 +1 ) && ( ordered_lines_y[i] < gray_resized_zone.rows - letter_h/2 - 1 ) ) {
      cout << "      on line " << i << endl;

      // Calcul sur la ligne
      // Position départ:
      int max_letter_step = 11;
      int augment = 10;
      int line_start = max(ordered_line_x_min[i] - augment, letter_w/2 + 1 );
      // Longueur de ligne : 110 + 20
      int line_length = min(max( 10 * max_letter_step + 2 * augment , ordered_line_x_max[i] - line_start + 2 * augment ), gray_resized_zone.cols - line_start - letter_w/2 - 1);

      vector<float> predictions;
      vector<Point> points;

      for(int j = 0; j < line_length ; j ++ ) {
        Rect r( Point2f(line_start + j - letter_w/2, ordered_lines_y[i] - letter_h/2) , Size(letter_w,letter_h)  );
        Mat letter_extract = gray_resized_zone( r );

        std::vector<float> output = positioning_classifier->Predict(letter_extract);
        // cout << output.size() << " - " << endl;
        //cout << "Result : " << output[0] << endl;

        points.push_back( Point2f(line_start + j, ordered_lines_y[i]) );
        predictions.push_back(output[0]);
        letter_extract.release();
      }

      // Calcul de la grille max
      float max_score = 0.0;
      int max_line_s = 0;
      float max_letter_s = 9.5;
      for(float letter_step = 9.5; letter_step < 10.9 ; letter_step = letter_step + 0.1)
        for(int line_s = 0; line_s < line_length - (int)(9.0 * letter_step) - 1 ; line_s ++ ) {
          float sum = 0.0;
          for(float l = 0.0; l < 10.0 ; l = l + 1.0 ) {
            sum += predictions[line_s + (int)(l * letter_step)];
          }
          if( sum > max_score ) {
            max_score = sum;
            max_line_s = line_s;
            max_letter_s = letter_step;
          }
        }
      //cout << "Max score " << max_score << " at position " << line_start + max_line_s << " and letter step " << max_letter_s <<  endl;
      vector<cv::RotatedRect> orderedRotatedRects;
      for( int l = 0.0 ; l < 10.0 ; l = l + 1.0 ){
        //read letter
        RotatedRect r ( Point2f (line_start + max_line_s + (int)(l * max_letter_s) , ordered_lines_y[i] ) , Size2f(letter_w,letter_h), 0.0 );
        if( is_in_image( r, gray_resized_zone))
          orderedRotatedRects.push_back( r );
        else
          cout << "        Letter not in image " << endl;

      }
      ordered_lines_RotatedRects.push_back(orderedRotatedRects);

    }
  }
}

void most_probable_month(std::vector<float> output1, std::vector<float> output2, string &month, float & month_proba ) {

  month_proba = 0.0;
  char month_c [3] ;
  month_c[2] = '\0';
  // ensemble des chaines possibles
  for(int i = 0; i < 2 ; i ++) { // 0 ou 1
    int max_d = 10;
    int min_d = 1 ;
    if(i == 1) {max_d = 3; min_d = 0;};
    for(int j = min_d; j < max_d ; j ++ ) {
      float score = output1[i]+ output2[j];
      if( score > month_proba) {
        month_c[0] = driving_letters[i];
        month_c[1] = driving_letters[j];
        month = month_c;
        month_proba = score;
      }
    }
  }

}

void most_probable_year(std::vector<float> output1, std::vector<float> output2, std::vector<float> output3, std::vector<float> output4, string &year, float & year_proba) {

  year_proba = 0.0;
  char year_c [5];
  year_c[4] = '\0';
  for(int i = 0; i < 12; i ++) {// 190x, 191x, 192x, 193x, 194x, 195x, 196x ... 199x, 200x, 201x
    float prob ;
    if(i == 10) {
      prob = output1[2] + output2[0] + output3[0];
      year_c [0] = '2';
      year_c [1] = '0';
      year_c [2] = '0';
    } else if(i == 11) {
      prob = output1[2] + output2[0] + output3[1];
      year_c [0] = '2';
      year_c [1] = '0';
      year_c [2] = '1';
    } else {
      prob = output1[1] + output2[9] + output3[i];
      year_c [0] = '1';
      year_c [1] = '9';
      year_c [2] = driving_letters[i];
    }
    int max_d = 10;
    if(i == 11) max_d = 7;
    for(int j = 0; j < max_d ; j ++) {
      float score = prob + output4[j];
      if( score > year_proba) {
        year_c [3] = driving_letters[j];
        year = year_c ;
        year_proba = score;
      }
    }
  }
};

void DrivingLicense::read_letters(ImageTorrefactor * reading_classifier, string & res, float & line_score_max) {
  cout << "    Reading lines : " << endl;
  // calcul du score pour chaque ligne
  for(int i = 0 ; i < ordered_lines_RotatedRects.size() ; i ++) {
    int nb_positions = ordered_lines_RotatedRects[i].size();

    // get rid of lines that are not made of 10 positions
    if(nb_positions != 10) {
      line_scores.push_back( 0.0 ) ;
      line_strings.push_back( "" );
      continue;
    }

    // calcul des prédictions pour chaque position sur la ligne
    std::vector< std::vector<float> > outputs;
    for( int l = 0; l < nb_positions ; l ++ )
      outputs.push_back( reading_classifier->Predict(multiplyBy(gray_resized_zone(ordered_lines_RotatedRects[i][l].boundingRect()), 0.00390625)) );

    // calcul de la probabilité
    string month, year; float month_proba, year_proba;
    most_probable_month(outputs[3], outputs[4], month, month_proba);
    most_probable_year(outputs[6],outputs[7],outputs[8],outputs[9], year, year_proba );

    // comparons la probabilité d'une ligne date avec la probabilité d'une ligne '********' sur les 7 dernières positions
    float line_proba = outputs[2][10] + month_proba + outputs[5][10] + year_proba; // 10 correspond au caractère '/'
    float star_line_proba = outputs[2][11] + outputs[3][11] + outputs[4][11] + outputs[5][11] + outputs[6][11] + outputs[7][11] + outputs[8][11] + outputs[9][11]; // 11 correspond au caractère '*'

    if( line_proba > star_line_proba) {
      line_scores.push_back( line_proba ) ;
      line_strings.push_back( month + "/" + year );
      cout << "      line " << i << " : " << month + "/" + year << " - " << line_proba << endl;
    } else {
      line_scores.push_back( 0.0 ) ;
      line_strings.push_back( "" );
    }
  }

  //calcul de la ligne de score max, sans > 3* ou 3 /
  line_score_max = 0.0;
  int line_max_index = 0;
  res = "";
  for(int i = 0 ; i < line_scores.size(); i ++ ) {
    if( line_scores[i] > line_score_max ) { // && std::count(line_strings[i].begin(), line_strings[i].end(), '*' ) < 3 && std::count(line_strings[i].begin(), line_strings[i].end(), '/' ) < 4
      line_score_max = line_scores[i];
      line_max_index = i;
      res = line_strings[line_max_index];
    }
  }
  displayText(c_gray_resized_zone,res,Point(0,5), 0.5);
  ;//.substr(3)
}

void DrivingLicense::write_detections(string outpath) {
  for(int i = 0 ; i < zones.size(); i++)
    displayRectangle(image, zones[i]);
  imwrite( outpath, image );
}

void DrivingLicense::write_zone(string rz_path) {
  cout << "    Writing zones to file" << endl;
  for(int i = 0 ; i < ordered_lines_RotatedRects.size() ; i ++)
    for( int l = 0; l < ordered_lines_RotatedRects[i].size() ; l ++ )
      displayCross(c_gray_resized_zone, ordered_lines_RotatedRects[i][l].center);

  imwrite(rz_path , c_gray_resized_zone);
};

void DrivingLicense::write_zone(string rz_path, string path, std::ofstream * outfile) {
  cout << "    Writing zones to file" << endl;
  for(int i = 0 ; i < ordered_lines_RotatedRects.size() ; i ++)
    for( int l = 0; l < ordered_lines_RotatedRects[i].size() ; l ++ )
      *outfile << path << ",," <<  ordered_lines_RotatedRects[i][l].center.x << "," << ordered_lines_RotatedRects[i][l].center.y << "," << ordered_lines_RotatedRects[i][l].size.width << "," << ordered_lines_RotatedRects[i][l].size.height << "," << ordered_lines_RotatedRects[i][l].angle << endl;

  //displayCross(c_gray_resized_zone, ordered_lines_RotatedRects[i][l].center);

  imwrite(rz_path , c_gray_resized_zone);
};

void DrivingLicense::release() {
  WorkImage::release();
  c_gray_resized_zone.release();
  gray_resized_zone.release();
};
