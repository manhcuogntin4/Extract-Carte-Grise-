#include "DrivingLicense.h"
#include <glog/logging.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{

  if( argc != 7)
  {
   cout <<" Usage: ./read Drivinglicense cascade.xml position_model_prefix read_model_prefix input_dir output_dir" << endl;
   return -1;
  }

  CHECK_EQ(mkdir(argv[6], 0744), 0)
      << "mkdir " << argv[6] << " failed";

  ImageTorrefactor * positioning_classifier = new ImageTorrefactor(string(argv[3]) + string(".prototxt"),string(argv[3]) + string(".caffemodel"));
  ImageTorrefactor * reading_classifier = new ImageTorrefactor(string(argv[4]) + string(".prototxt"),string(argv[4]) + string(".caffemodel"));
  CascadeClassifier* cc = new CascadeClassifier(string(argv[2])) ;

  std::ofstream outfile;
  outfile.open( (std::string(argv[6]) + "/results.csv").c_str(), std::ios_base::app);

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[5]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);

    DrivingLicense dl ( std::string(argv[5]) + "/" + std::string(entry->d_name) );
    if( dl.ok ) {
      cout << "  Find zones" << endl;
      dl.findZones(cc);
      for(int i = 0 ; i < dl.zones.size(); i++) {
        cout << "  Zone " << i << endl;
        dl.compute_lines(positioning_classifier, dl.zones[i]);
        dl.compute_letter_positions(positioning_classifier);
        dl.read_letters(reading_classifier);
        dl.write_zone(string(argv[6]) + "/" + std::string(entry->d_name) + std::to_string(i) + ".jpg");

      }
      dl.release();
    }
  }
  outfile.close();
  return 0;
}
