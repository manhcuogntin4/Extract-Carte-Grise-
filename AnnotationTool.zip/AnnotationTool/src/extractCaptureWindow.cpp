#include <gflags/gflags.h>
#include <glog/logging.h>
#include <google/protobuf/text_format.h>
//#include <leveldb/db.h>
//#include <leveldb/write_batch.h>
#include <lmdb.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"


#define PI 3.14159265

#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <fstream>

using namespace cv;
using namespace std;

#include <fstream>  // NOLINT(readability/streams)
#include <string>

#include "caffe/proto/caffe.pb.h"
#include "Utils.h"

using namespace caffe;  // NOLINT(build/namespaces)
using std::string;

DEFINE_int32(factor, 1, "The number of negatives per positive [default:3]");
DEFINE_int32(max, 400, "The max scale for capture window width. [default:400]");
DEFINE_int32(min, 160, "The min scale for capture window width. [default:160]");
DEFINE_double(ratio, 1.0, "The ratio of capture window height/width [default:1.0]");
DEFINE_bool(rotated, false, "The format : Rect or RotatedRect [Default : false]");
DEFINE_bool(correct, false, "Correct the ratio of the input rectangle [Default : false]");
DEFINE_bool(random, false, "Random points for negatives[Default : false]");
DEFINE_int32(noise, 0, "The number of noised samples of the rectangle to create. Default value is no noise. [default:0]");
DEFINE_double(noise_stride, 4.0, "The noise stride [default:4.0]");

uint32_t swap_endian(uint32_t val) {
    val = ((val << 8) & 0xFF00FF00) | ((val >> 8) & 0xFF00FF);
    return (val << 16) | (val >> 16);
}


void write_rect(Mat gray_image, Point center, Size s, string label, Point delta, string db_path, string output_path, std::ofstream * outfile ) {
  Rect rr( center - Point( s.width / 2.0 , s.height / 2.0), s);
  if( is_in_image(rr,gray_image)) {
    Mat extracted_image = gray_image( rr );
    imwrite( db_path + "/" + output_path , extracted_image );
    *outfile << output_path << "," << label << "," << delta.x << "," << delta.y << endl;
    (*outfile).flush();
    extracted_image.release();
  } else cout << "Rectangle outside of image" << endl;
}

void convert_dataset(const char* csv_filename, const char* db_path, int nb_negatives_per_positive, int max_w, int min_w,  double ratio, bool rotated, bool correct, bool random, int noise, double noise_stride) {
  // Open input files
  std::vector<std::vector<std::string> > input;
  readCSV( csv_filename , input);

  string base_path = getbase(csv_filename);
  cout << "Base path: " << base_path << endl;

  // get rectangles for each unique input_path
  std::vector<std::string> input_path;
  std::vector<std::vector<string> > input_labels;
  std::vector<std::vector<RotatedRect> > input_rotatedrects;
  group_by_image(input, rotated, correct, ratio, input_path, input_labels, input_rotatedrects);

  const int cols = max_w;
  const int rows = cols * ratio;
  // LOG(INFO) << "Rows: " << rows << " Cols: " << cols;
  cout << "Capture window : " << cols << " x " << rows << " (ratio: " << ratio << ")" << endl;
  cout << "Sample negative windows per positive: " << nb_negatives_per_positive << endl;

  //statistics
  double average_width = 0;
  double average_height = 0;
  int average_count = 0;
  int max_width = 0;
  int min_width = 1000000000;
  int max_height = 0;
  int min_height = 1000000000;
  int min_orientation = 90;
  int max_orientation = -90;

  // initiate directories or db
  LOG(INFO) << "Creating directory " << db_path;
  CHECK_EQ(mkdir(db_path, 0744), 0)
      << "mkdir " << db_path << " failed";
  std::ofstream outfile;
  outfile.open( std::string( db_path ) + "/annotations.csv", std::ios_base::app);

  int item_id = 0;
  for(int cursor = 0; cursor < input_path.size(); cursor++) {

    Mat image = imread(base_path+input_path[cursor], CV_LOAD_IMAGE_COLOR);   // Read the file
    if(! image.data )                              // Check for invalid input
    {
        std::cout <<  "Could not open or find the image " << base_path+input_path[cursor] << std::endl ;
    } else {
      int height = image.rows, width = image.cols, area = height * width, channel = image.channels();

      Mat gray_image;
      cvtColor(image,gray_image,CV_BGR2GRAY);
      cout << "Item " << item_id << ": " << input_path[cursor] << endl;

      // computation of random points (as many as the number of rectangles)
      int neg = 0;
      std::vector<Point> random_points;
      int num_neg = (noise)?(input_rotatedrects[cursor].size()*noise):input_rotatedrects[cursor].size();
      while( neg < num_neg ) {
        int ss_x1 = rand() % (width - cols)  ;
        int ss_y1 = rand() % (height  - rows) ;

        Point p (ss_x1+ cols/2, ss_y1+ rows/2);

        int square_dist_min = 100000000;
        for(int i = 0; i < input_rotatedrects[cursor].size(); i ++) {
          square_dist_min = std::min(square_dist_min, int((p.x - input_rotatedrects[cursor][i].center.x) * (p.x - input_rotatedrects[cursor][i].center.x)+ (p.y - input_rotatedrects[cursor][i].center.y) * (p.y - input_rotatedrects[cursor][i].center.y)));
        }
        if(square_dist_min > std::max(cols * cols, rows*rows)) {
          neg++;
          random_points.push_back(p);
        }
      }

      // extraction of the positive points
      for( int i = 0; i < input_rotatedrects[cursor].size(); i ++ ) {
        Point p = input_rotatedrects[cursor][i].center;
        string label = input_labels[cursor][i];

        if(noise)
          for( int j = 0; j < noise; j ++) {
            float delta_x = - noise_stride / 2.0 + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/ noise_stride ));
            float delta_y = - noise_stride / 2.0 + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/ noise_stride ));
            cout << "Delta " << delta_x << " - " << delta_y << endl;
            write_rect(gray_image, p + Point(delta_x,delta_y) , Size(((float)cols),((float)rows)), label, Point(-delta_x,-delta_y), std::string( db_path ),std::to_string(item_id) + "_" + std::to_string(i) +"_" + std::to_string(j) + ".png", &outfile );
            item_id ++;
          }
        else {
          write_rect(gray_image, p, Size(((float)cols),((float)rows)), label, Point(0,0), std::string( db_path ), std::to_string(item_id) +"_" + std::to_string(i) + ".png", &outfile );
          item_id ++;
        }
      }

      //extract negative points
      for( int i = 0; i < num_neg; i ++ ) {
        Point p = random_points[i];
        string label = "";
        write_rect(gray_image, p, Size(((float)cols),((float)rows)), label, Point(0,0),  std::string( db_path ), "_" + std::to_string(item_id) + "_" + std::to_string(i) + ".png", &outfile );
        item_id ++;
      }

      gray_image.release();
    }
    image.release();
  }
  // close
  outfile.close();
}

// MAIN FUNCTION
int main(int argc, char** argv) {
#ifndef GFLAGS_GFLAGS_H_
  namespace gflags = google;
#endif

  gflags::SetUsageMessage("This script extracts rectangles to\n"
        "the format used by Caffe or OpenCV to train data.\n"
        "Usage:\n"
        "    extractCaptureWindow [FLAGS] input_csv_file output_dir"
        "\n");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  const double& ratio = FLAGS_ratio;
  const int& factor = FLAGS_factor;
  const int& max = FLAGS_max;
  const int& min = FLAGS_min;
  const bool& rotated = FLAGS_rotated;
  const bool& correct = FLAGS_correct;
  const bool& random = FLAGS_random;
  const int& noise = FLAGS_noise;
  const double& noise_stride = FLAGS_noise_stride;

  if (argc != 3) {
    gflags::ShowUsageWithFlagsRestrict(argv[0],
        "examples/mnist/convert_mnist_data");
  } else {
    google::InitGoogleLogging(argv[0]);
    convert_dataset(argv[1], argv[2], factor, max, min,  ratio, rotated, correct, random, noise, noise_stride);
  }
  return 0;
}
