#include "Utils.h"
#include "ImageTorrefactor.h"


class DrivingLicense : public WorkImage
{

public:

    // network configuration
    static const int input_width , input_height ;
    static const float rx  ;
    // ry = 0.55;
    // ry2 = 0.20;

    int output_width ;
    int output_height ;

    static const int letter_w, letter_h;

    float ry2 ;

    vector<cv::Rect> zones;

    // Current elements :
    //zone
    cv::Mat gray_resized_zone;
    cv::Mat c_gray_resized_zone;// For display only//
    //current lines
    vector<int> ordered_line_x_min;
    vector<int> ordered_line_x_max;
    vector< float > ordered_lines_y;
    vector<vector<cv::RotatedRect> > ordered_lines_RotatedRects;
    std::vector<float> line_scores ;
    std::vector<string> line_strings;

    DrivingLicense(std::string path) : WorkImage(path) {};

    void resize_original(float max_dim);
    void orientate(ImageTorrefactor * localizer);
    void findZones( CascadeClassifier* cc ) ;

    void compute_lines(ImageTorrefactor * positioning_classifier, cv::Rect zone);
    void compute_letter_positions(ImageTorrefactor * positioning_classifier);
    void read_letters(ImageTorrefactor * reading_classifier, string & res, float & line_score_max);

    int get_position_w( float y ) ;
    int get_position_h( float y ) ;

    void write_detections(string outpath);
    void write_zone(string outpath);
    void write_zone(string rz_path, string path, std::ofstream * outfile);
    void release();

};
