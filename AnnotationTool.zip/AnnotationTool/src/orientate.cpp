#include <glog/logging.h>
#include <sys/stat.h>
#include "Utils.h"
#include <math.h>

int main(int argc, char** argv)
{

  if( argc != 3)
  {
   cout <<" Usage: ./orientate input_dir output" << endl;
   return -1;
  }

  CHECK_EQ(mkdir( argv[2] , 0744), 0)
    << "mkdir " << argv[2] << " failed";
  mkdir( (std::string(argv[2]) + "/_").c_str(), 0744);

  std::ofstream outfile;
  outfile.open(std::string(argv[2]) + "/results.csv", std::ios_base::app);

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[1]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);
    std::string path = std::string(argv[1]) + "/" + std::string(entry->d_name);
    std::string output_path = std::string(argv[2])+"/_/"+std::string(entry->d_name);

    WorkImage full_image (path);
    if(!! full_image.ok )                              // Check for invalid input
    {
      int rot = compute_orientation(full_image.image);
      //imwrite(output_path,cdst);
      RotatedRect r ( Point2f( full_image.width/2.0, full_image.height / 2.0), Size2f(full_image.width/2.0, full_image.height / 2.0), rot);
      imwrite(output_path,full_image.image);
      outfile << "_/"+std::string(entry->d_name) << ",," << r.center.x << "," << r.center.y << "," << r.size.width << "," << r.size.height << "," << r.angle << endl;
      outfile.flush();

    }
  }
  outfile.close();
  return 0;
}
