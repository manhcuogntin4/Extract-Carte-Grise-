#include "Utils.h"
#include <fstream>
using std::cout;
using std::endl;

int main( int argc, char** argv )
{
    if( argc != 3)
    {
     cout <<" Usage: ./bin/tempConvert input.csv output.csv" << endl;
     return -1;
    }

    std::vector<std::vector<std::string> > input;
    readCSV( argv[1] , input);

    string base_path = getbase(argv[1]);
    cout << "Base path: " << base_path << endl;

    std::ofstream outfile;
    outfile.open( std::string(argv[2]), std::ios_base::app);

    for(int i = 0; i < input.size(); i++) {
      int res_x = stoi(input[i][2]);
      int res_y = - stoi(input[i][3]);
      int res_w = stoi(input[i][4]);
      int res_h = stoi(input[i][5]);
      int res_r = stoi(input[i][6]) * 3.14159265 / 180;

      // Mat image = imread(base_path+input[i][0], CV_LOAD_IMAGE_COLOR);   // Read the file
      //
      // if(! image.data )                              // Check for invalid input
      // {
      //     std::cout <<  "Could not open or find the image " << base_path+input[i][0] << std::endl ;
      // } else {
      //   int height = image.rows, width = image.cols, area = height * width, channel = image.channels();
        // double factor = image.rows / 500;
        // if(factor > 1.5) {
        //   res_x = res_x * factor;
        //   res_y = res_y * factor;
        //   res_w = res_w * factor;
        //   res_h = res_h * factor;
        // }
        // res_x = res_x + res_w / 2;
        // res_y = res_y + res_h / 2;

        float factor_w = 3.1;
        float factor_h = 1.8;
        float factor_x = -0.7;
        float factor_y = -0.2;



        float x_after_rot = (cos(res_r) * res_x - sin(res_r) * res_y ) ; //+ factor_x * res_w;
        float y_after_rot = (sin(res_r) * res_x + cos(res_r) * res_y) + factor_y * res_h; //+ factor_y ;

        int new_x = (cos(-res_r) * x_after_rot - sin(-res_r) * y_after_rot );
        int new_y = (sin(-res_r) * x_after_rot + cos(-res_r) * y_after_rot ) ;
        int new_w = res_w * factor_w;
        int new_h = res_h * factor_h;


        outfile << input[i][0] << "," << input[i][1] << "," << new_x << ","<< - new_y << "," << new_w << "," << new_h << "," << input[i][6] << endl;

      // }
	    //  image.release();
    }

    outfile.close();
}
