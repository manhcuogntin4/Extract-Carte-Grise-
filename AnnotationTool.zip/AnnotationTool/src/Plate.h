#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/objdetect/objdetect.hpp"
#include <iostream>
#include <algorithm>
#include <set>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include "Utils.h"

using namespace cv;
using namespace std;

//void annotateImage ( std::string path , std::ofstream * output ) ;

class Plate
{

public:

    Plate();
    void annotateImage ( std::string path, std::ofstream * output );
    int _threshold_;
    int nbCluster ;

};
