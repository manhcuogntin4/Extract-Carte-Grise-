#include "ImageTesseractor.h"
#include "ImageTorrefactor.h"

int main(int argc, char** argv )
{

  if( argc != 3)
  {
   std::cout <<" Usage: ./scorePlates [tesseract|caffe] file.csv" << std::endl;
   return -1;
  }

  string technology = string(argv[1]);

  char lng[10] = "eng";
  // char lng[10] = "lpfra";
  ImageTesseractor tesseractor ( lng );
  ImageTorrefactor classifier("deploy.prototxt", "lenet_iter_2000.caffemodel"); //mean_file, label_file
  CascadeClassifier* plate_cc = new CascadeClassifier(string("models/plates.xml")) ;

  std::ifstream file(argv[2]);
  std::string str;
  int count =0 ;
  int total = 0;
  while (std::getline(file, str))
  {
      std::stringstream ss( str );
      vector<string> result;

      while( ss.good() )
      {
        string substr;
        getline( ss, substr, ',' );
        result.push_back( substr );
      }

      cout << result[0] << " : " << result[1] << endl;
      WorkImage image (result[0]);

      if(image.ok) {
        total ++;
        string r = "";
        vector<cv::Rect> plateZone;
        vector<vector<cv::Point> > all_contours;
        detectRectsAndContours(plate_cc,image, plateZone, all_contours);

        if(technology == "tesseract") {
          vector<cv::Rect> orderedRects;  vector<vector<cv::Point> > orderedContours;
          if(plateZone.size()>0 )
            extractRect(image,plateZone[0], all_contours,orderedContours,orderedRects);

          r = tesseractor.readRects( image, orderedRects );
        } else if( technology == "caffe") {
          vector<string> textV;
          for(int j = 0 ; j < plateZone.size(); j++ ) {
            vector<cv::Rect> orderedRects;  vector<vector<cv::Point> > orderedContours;
            extractRect(image,plateZone[j], all_contours,orderedContours,orderedRects);
            std::string text = classifier.readRects( image.gray_image , orderedRects, 2000 );
            textV.push_back(text);
          }

          displayRects(image.image,plateZone);

          int textmax = 0;
          int argtextmax = 0;
          for (int i = 0 ; i < textV.size() ; i ++ ) {
            if(textV[i].length() > textmax)
              {
                textmax = textV[i].length();
                argtextmax = i;
               }
          }
          if(textV.size() > 0)
            r = textV[argtextmax];

        } else cout << "Unrecognized technology" << endl;
        if(r == result[1]) count ++; else cout << "(Mismatch) " << str << endl ;
        cout << result[1] << ":"  <<  r << endl;
      }

      cout << "Score : " << count;
      cout << " sur " << total << endl;
  }
}
