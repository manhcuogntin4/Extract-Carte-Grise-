#include "DrivingLicense.h"
#include <glog/logging.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{

  if( argc != 6)
  {
   cout <<" Usage: ./annotateLetters orientation_model_prefix position_model_prefix cascade.xml input_dir output_dir" << endl;
   return -1;
  }

  CHECK_EQ(mkdir(argv[5], 0744), 0)
      << "mkdir " << argv[5] << "failed";
  mkdir( (string(argv[5]) + "/_").c_str(), 0744);

  std::ofstream outfile;
  outfile.open( (std::string(argv[5]) + "/results.csv").c_str(), std::ios_base::app);

  CascadeClassifier* cc = new CascadeClassifier(string(argv[3])) ;
  ImageTorrefactor * orientation_localizer = new ImageTorrefactor( string(argv[1]) + string("/deploy.prototxt"),string(argv[1]) + string("/train_val.caffemodel"));
  ImageTorrefactor * positioning_classifier = new ImageTorrefactor(string(argv[2]) + string(".prototxt"),string(argv[2]) + string(".caffemodel"));

  struct dirent *entry;
  int ret = 1;
  DIR *dir;
  dir = opendir (argv[4]);

  if( dir == NULL) {
    cout << "input dir does not exist" << endl;
    return -1;
  }

  while ((entry = readdir (dir)) != NULL) {
    printf("Recognizing %s\n",entry->d_name);

    DrivingLicense dl ( std::string(argv[4]) + "/" + std::string(entry->d_name) );
    if( dl.ok ) {
      dl.orientate(orientation_localizer);
      cout << "  Find zones" << endl;
      dl.findZones(cc);
      for(int i = 0 ; i < dl.zones.size(); i++) {
        cout << "  Zone " << i << endl;
        dl.compute_lines(positioning_classifier, dl.zones[i]);
        dl.compute_letter_positions(positioning_classifier);
        dl.write_zone(string(argv[5]) + "/_/" + std::string(entry->d_name) + std::to_string(i) + ".jpg","_/" + std::string(entry->d_name) + std::to_string(i) + ".jpg", &outfile);
      }
      dl.release();
    }


    // Mat image = imread(std::string(argv[3]) + "/" + std::string(entry->d_name), CV_LOAD_IMAGE_COLOR);
    // if(! image.data )                              // Check for invalid input
    // {
    //     std::cout <<  "Could not open or find the image" << std::endl ;
    // } else {
    //
    //   dl.read(image, string(argv[4]) + "/" + std::string(entry->d_name), zones);
    //   image.release();
    //
    //   // *outfile << path << "," << endl;
    //   // (*outfile).flush();
    //
    // }

  }
  outfile.close();
  return 0;
}
