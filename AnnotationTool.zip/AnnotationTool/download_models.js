var dirs = [
  "models",
  "models/driving",
  "models/driving2",
  "results",
  "models/plates_letters",
  "models/types",
  "models/driving_full_translation_rotation_scale_googlenet"
]
var files = [
  "permis_A_A1_featuremap.prototxt",
  "driving.xml",
  "plates.xml",
  "plates_letters/cv_lenet_solver.prototxt",
  "plates_letters/cv_lenet_train_test.prototxt",
  "plates_letters/deploy.prototxt",
  "plates_letters/deploy.caffemodel",
  "plates_letters/lenet_solver.prototxt",
  "plates_letters/lenet_train_test.prototxt",
  "plates_letters/lenet_train_test_featuremap.prototxt",
  "driving_full_translation_rotation_scale_googlenet/train_val.prototxt",
  "driving_full_translation_rotation_scale_googlenet/train_val.caffemodel",
  "driving/read.prototxt",
  "driving/position.prototxt",
  "driving/read.caffemodel",
  "driving/position.caffemodel",
  "driving/orientation.prototxt",
  "driving/orientation.caffemodel",
  "driving2/deploy.prototxt",
  "driving2/train_val.prototxt",
  "driving2/train_val_featuremap.prototxt",
  "driving2/train_val_featuremap.caffemodel",
  "types/train_val.prototxt",
  "types/train_val.caffemodel"
];

/// CREATE DIRECTORY MODEL IF NOT EXISTS
var fs    = require('fs')
  , path  = require('path');
var mkdirSync = function (path) {
  try {
    fs.mkdirSync(path);
  } catch(e) {
    if ( e.code != 'EEXIST' ) throw e;
  }
}
for( var i = 0; i < dirs.length; i++)
  mkdirSync(dirs[i])

/// DOWNLOAD MODELS
var AWS = require('aws-sdk');
var s3 = new AWS.S3();


for( var i = 0; i < files.length; i++) {
  var file = files[i];

  console.log("Downloading " + file + " ... ");
  if (fs.existsSync( "models/" + file)) {
    console.log("Already downloaded")
  } else {

	var params = {Bucket: 'axard', Key: "models/" + file};
  	var file = require('fs').createWriteStream( "models/" + file);
	s3.getObject(params).createReadStream().pipe(file);
  }
}
