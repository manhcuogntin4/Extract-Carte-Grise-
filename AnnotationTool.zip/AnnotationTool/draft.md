Extract for Caffe training - TODO

Create a `results.csv` file in output_dir and save images with annotations for verification.


    WIDTH=100
    RATIO=0.25
    NUMPOS=1023
    FACTOR=1
    ./bin/extractRect --correct --ratio=$RATIO --width=$WIDTH --factor=$FACTOR --backend=caffe $DATA_ROOT/rr_plates.csv results/plates-caffe-$WIDTH-$RATIO-$FACTOR


Extract the 400x100 window and resize it to 100x25.
Attribute a class to the extracted window given the object size in the window : the number of classes corresponds to the number of scales (from --max to --min) + 2. The last 2 classes corresponds to "negative" (IOU < 0.3) and "to ignore" (0.3 < IOU < 0.7). The class corresponds to the max scale where IOU > 0.7.

Create a network :
    python python/transform_to_convolution.py  models/lenet_train_test_withoutdata.prototxt models/lenet_iter_2000.caffemodel models/lenet_train_test_featuremap.prototxt models/lenet_train_test_featuremap.caffemodel

You can train the network :

    python python/lenet1_image/train_net.py

To convert it to a feature map, have a look at [iPython notebook example](Have a look.ipynb).







Extract and train Driving licenses with Caffe

    WIDTH=227
    ./bin/extractRect --rotated --ratio=$RATIO --width=$WIDTH --factor=$FACTOR --backend=caffe $DATA_ROOT/rr_permis_A_A1.csv results/permis_A_A1-caffe-$WIDTH-$RATIO-$FACTOR






        ./bin/extractCaptureWindow $DATA_ROOT/rr_permis_A_A1_letters.csv ttt222222x --ratio=1.2 --max=20 --random
        ./bin/extractCaptureWindow $DATA_ROOT/rr_permis_A_A1_letters.csv ttt222222y --ratio=1.2 --max=20
        cd x
        for i in *.png; do echo $i 1 >> train.txt ; done
        cd ../y
        for i in *.png; do echo $i O >> train.txt ; done




          WIDTH=18
          ./bin/extractCaptureWindow $DATA_ROOT/permis_A_A1_letters-lettersonly.csv results/permis_A_A1/img_letters_only_${WIDTH}_$RATIO  --ratio=$RATIO --max=$WIDTH

          ./bin/extractCaptureWindow $DATA_ROOT/permis_A_A1_letters-lettersonly.csv results/permis_A_A1/img_letters_only_${WIDTH}_$RATIO --ratio=$RATIO  --max=$WIDTH --random

          cd results/permis_A_A1/img_letters_only_${WIDTH}_$RATIO
          for i in *.png; do echo $i 0 >> train.txt ; done

          cd ../../../img_letters_only_${WIDTH}_$RATIO
          for i in *.png; do mv $i 1_$i ; done
          for i in *.png; do echo $i 1 >> train.txt ; done
          for i in *.png; do mv $i ../python/driving_lenet/img_letters_only_${WIDTH}_$RATIO/$i ; done
          cat train.txt >> ../python/driving_lenet/img_letters_only_${WIDTH}_$RATIO/train.txt
          cd ..
          rm -r img_letters_only_${WIDTH}_$RATIO

        -----

        ./bin/annotateLetters models/permis_A_A1_redressed-opencv-50-0.85-10.xml models/driving_featuremap  $DATA_ROOT/permis_A_A1_redressed output_dir

            ./bin/readDrivinglicense models/permis_A_A1_redressed-opencv-50-0.85-10.xml models/driving_featuremap $DATA_ROOT/permis_A_A1_redressed output_dir
