from python import *

caffe.set_mode_gpu()
t = ['0','1','2','3','4','5','6','7','8','9','*','/'];
im = np.array(Image.open('input/8.png'))
print "Image shape", im.shape
im = im[:25,:18]
net = caffe.Net('python/driving_letters_read2_with_stn_daerduoCarey/deploy.prototxt','python/driving_letters_read2_with_stn_daerduoCarey/train_val.caffemodel',caffe.TEST)

im_input = im[np.newaxis, np.newaxis, :, :] * 0.00390625
net.blobs['data'].reshape(*im_input.shape)
net.blobs['data'].data[...] = im_input
#net.forward()
out = net.forward(start="loc_conv1")
output1=net.blobs['st_output'].data

print "Classe : ", t[net.blobs['ip2'].data[0].argmax()]

caffe.set_mode_cpu()
net.forward()
output2=net.blobs['st_output'].data
print output1-output2
#print "#" * 50
#print net.blobs['theta'].data
#print "#" * 50
print net.blobs['st_output'].data
print t[net.blobs['ip2'].data[0].argmax()]
dir = "2"
images = os.listdir("results/permis_A_A1_extracted_letters_further/"+dir)
images = images[:50]
print images
for i in images:
    print i
    im = np.array(Image.open('results/permis_A_A1_extracted_letters_further/' + dir + '/'+i))
    im_input = im[np.newaxis, np.newaxis, :, :] * 0.00390625
    net.blobs['data'].reshape(*im_input.shape)
    net.blobs['data'].data[...] = im_input
    net.forward()
    print("The result is {}".format(t[net.blobs['ip2'].data[0].argmax()]))
    print("The theta is ")
    for j in range(6):
        print net.blobs['theta'].data[0,j]
